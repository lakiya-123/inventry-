<?php
// Get current user data
$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

// Process profile update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    $full_name = sanitize_input($_POST['full_name']);
    $email = sanitize_input($_POST['email']);
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
    
    $update_password = false;
    
    // Validate current password if trying to change password
    if (!empty($new_password)) {
        if (empty($current_password)) {
            $_SESSION['error_message'] = "Current password is required to set a new password.";
        } else if (!password_verify($current_password, $user['password'])) {
            $_SESSION['error_message'] = "Current password is incorrect.";
        } else if ($new_password !== $confirm_password) {
            $_SESSION['error_message'] = "New passwords do not match.";
        } else {
            $update_password = true;
        }
    }
    
    // If no errors or not updating password
    if (!isset($_SESSION['error_message'])) {
        if ($update_password) {
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("UPDATE users SET full_name = ?, email = ?, password = ? WHERE id = ?");
            $stmt->bind_param("sssi", $full_name, $email, $hashed_password, $user_id);
        } else {
            $stmt = $conn->prepare("UPDATE users SET full_name = ?, email = ? WHERE id = ?");
            $stmt->bind_param("ssi", $full_name, $email, $user_id);
        }
        
        if ($stmt->execute()) {
            // Update session variables
            $_SESSION['user_name'] = $full_name;
            
            // Log activity
            log_activity($user_id, 'update', $user_id, 'user', "Updated profile information");
            
            $_SESSION['success_message'] = "Profile updated successfully!";
        } else {
            $_SESSION['error_message'] = "Error updating profile: " . $conn->error;
        }
    }
    
    // Redirect to prevent form resubmission
    header("Location: index.php?page=settings");
    exit();
}
?>

<h1>Settings</h1>

<!-- Success and Error Messages -->
<?php if (isset($_SESSION['success_message'])): ?>
    <div class="alert alert-success">
        <?php 
            echo $_SESSION['success_message']; 
            unset($_SESSION['success_message']);
        ?>
    </div>
<?php endif; ?>

<?php if (isset($_SESSION['error_message'])): ?>
    <div class="alert alert-danger">
        <?php 
            echo $_SESSION['error_message']; 
            unset($_SESSION['error_message']);
        ?>
    </div>
<?php endif; ?>

<div class="form-container">
    <h2 class="form-title">Profile Information</h2>
    
    <form action="index.php?page=settings" method="POST" data-validate>
        <input type="hidden" name="update_profile" value="1">
        
        <div class="form-row">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" class="form-control" value="<?php echo htmlspecialchars($user['username']); ?>" disabled>
                <small>Username cannot be changed</small>
            </div>
            
            <div class="form-group">
                <label for="full_name">Full Name</label>
                <input type="text" id="full_name" name="full_name" class="form-control" value="<?php echo htmlspecialchars($user['full_name']); ?>" required>
            </div>
        </div>
        
        <div class="form-row">
            <div class="form-group">
                <label for="email">Email Address</label>
                <input type="email" id="email" name="email" class="form-control" value="<?php echo htmlspecialchars($user['email']); ?>" required>
            </div>
            
            <div class="form-group">
                <label for="role">Role</label>
                <input type="text" id="role" class="form-control" value="<?php echo ucfirst(htmlspecialchars($user['role'])); ?>" disabled>
            </div>
        </div>
        
        <h3>Change Password</h3>
        <p>Leave blank if you don't want to change your password</p>
        
        <div class="form-row">
            <div class="form-group">
                <label for="current_password">Current Password</label>
                <input type="password" id="current_password" name="current_password" class="form-control">
            </div>
        </div>
        
        <div class="form-row">
            <div class="form-group">
                <label for="new_password">New Password</label>
                <input type="password" id="new_password" name="new_password" class="form-control">
            </div>
            
            <div class="form-group">
                <label for="confirm_password">Confirm New Password</label>
                <input type="password" id="confirm_password" name="confirm_password" class="form-control">
            </div>
        </div>
        
        <div class="form-actions">
            <button type="submit" class="btn btn-primary">Save Changes</button>
        </div>
    </form>
</div>