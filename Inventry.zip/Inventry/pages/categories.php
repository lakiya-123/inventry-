<?php
// Check if we need to process any actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Add new category
    if (isset($_POST['add_category'])) {
        $name = sanitize_input($_POST['name']);
        $description = sanitize_input($_POST['description']);
        $type = sanitize_input($_POST['type']);
        
        // Insert into database
        $stmt = $conn->prepare("INSERT INTO categories (name, description, type) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $name, $description, $type);
        
        if ($stmt->execute()) {
            $category_id = $conn->insert_id;
            
            // Log activity
            log_activity($_SESSION['user_id'], 'add', $category_id, 'category', "Added category: $name");
            
            // Set success message
            $_SESSION['success_message'] = "Category added successfully!";
        } else {
            $_SESSION['error_message'] = "Error adding category: " . $conn->error;
        }
        
        // Redirect to prevent form resubmission
        header("Location: index.php?page=categories");
        exit();
    }
    
    // Update category
    if (isset($_POST['update_category'])) {
        $category_id = (int)$_POST['category_id'];
        $name = sanitize_input($_POST['name']);
        $description = sanitize_input($_POST['description']);
        $type = sanitize_input($_POST['type']);
        
        // Update database
        $stmt = $conn->prepare("UPDATE categories SET name = ?, description = ?, type = ? WHERE id = ?");
        $stmt->bind_param("sssi", $name, $description, $type, $category_id);
        
        if ($stmt->execute()) {
            // Log activity
            log_activity($_SESSION['user_id'], 'update', $category_id, 'category', "Updated category: $name");
            
            // Set success message
            $_SESSION['success_message'] = "Category updated successfully!";
        } else {
            $_SESSION['error_message'] = "Error updating category: " . $conn->error;
        }
        
        // Redirect to prevent form resubmission
        header("Location: index.php?page=categories");
        exit();
    }
    
    // Delete category
    if (isset($_POST['delete_category'])) {
        $category_id = (int)$_POST['category_id'];
        
        // Check if category has items
        $stmt = $conn->prepare("SELECT COUNT(*) as count FROM inventory WHERE category_id = ?");
        $stmt->bind_param("i", $category_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        
        if ($row['count'] > 0) {
            $_SESSION['error_message'] = "Cannot delete category. It has {$row['count']} inventory items associated with it.";
        } else {
            // Get category details for logging
            $category = get_category($category_id);
            
            if ($category) {
                // Delete category from database
                $stmt = $conn->prepare("DELETE FROM categories WHERE id = ?");
                $stmt->bind_param("i", $category_id);
                
                if ($stmt->execute()) {
                    // Log activity
                    log_activity($_SESSION['user_id'], 'delete', $category_id, 'category', "Deleted category: {$category['name']}");
                    
                    // Set success message
                    $_SESSION['success_message'] = "Category deleted successfully!";
                } else {
                    $_SESSION['error_message'] = "Error deleting category: " . $conn->error;
                }
            } else {
                $_SESSION['error_message'] = "Category not found.";
            }
        }
        
        // Redirect to prevent form resubmission
        header("Location: index.php?page=categories");
        exit();
    }
}

// Get filter from GET parameters
$type_filter = isset($_GET['type']) ? sanitize_input($_GET['type']) : null;

// Get categories with optional type filter
$categories = get_categories($type_filter);
?>

<h1>Categories Management</h1>

<!-- Success and Error Messages -->
<?php if (isset($_SESSION['success_message'])): ?>
    <div class="alert alert-success">
        <?php 
            echo $_SESSION['success_message']; 
            unset($_SESSION['success_message']);
        ?>
    </div>
<?php endif; ?>

<?php if (isset($_SESSION['error_message'])): ?>
    <div class="alert alert-danger">
        <?php 
            echo $_SESSION['error_message']; 
            unset($_SESSION['error_message']);
        ?>
    </div>
<?php endif; ?>

<!-- Filter Form -->
<div class="filter-container">
    <form action="index.php" method="GET" class="filter-form">
        <input type="hidden" name="page" value="categories">
        
        <div class="filter-group">
            <label for="type">Category Type</label>
            <select name="type" id="type" class="filter-input">
                <option value="">All Types</option>
                <option value="livestock" <?php echo ($type_filter == 'livestock') ? 'selected' : ''; ?>>Livestock</option>
                <option value="equipment" <?php echo ($type_filter == 'equipment') ? 'selected' : ''; ?>>Equipment</option>
                <option value="crops" <?php echo ($type_filter == 'crops') ? 'selected' : ''; ?>>Crops</option>
                <option value="supplies" <?php echo ($type_filter == 'supplies') ? 'selected' : ''; ?>>Supplies</option>
            </select>
        </div>
        
        <div class="filter-buttons">
            <button type="submit" class="btn btn-primary">Filter</button>
            <a href="index.php?page=categories" class="btn btn-outline">Reset</a>
        </div>
    </form>
</div>

<!-- Categories Table -->
<div class="page-header">
    <h2>Categories</h2>
    <button class="btn btn-primary" data-modal-target="addCategoryModal">
        <i class="fas fa-plus"></i> Add New Category
    </button>
</div>

<div class="data-container">
    <?php if (count($categories) > 0): ?>
        <table class="data-table" id="categoriesTable">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Type</th>
                    <th>Description</th>
                    <th>Items Count</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($categories as $index => $category): ?>
                    <?php
                        // Count items in this category
                        $stmt = $conn->prepare("SELECT COUNT(*) as count FROM inventory WHERE category_id = ?");
                        $stmt->bind_param("i", $category['id']);
                        $stmt->execute();
                        $result = $stmt->get_result();
                        $row = $result->fetch_assoc();
                        $items_count = $row['count'];
                    ?>
                <tr>
                    <td><?php echo $index + 1; ?></td>
                    <td><?php echo htmlspecialchars($category['name']); ?></td>
                    <td>
                        <span class="item-status" style="background-color: 
                            <?php
                                switch($category['type']) {
                                    case 'livestock': echo '#E8F5E9'; break;
                                    case 'equipment': echo '#E3F2FD'; break;
                                    case 'crops': echo '#F1F8E9'; break;
                                    case 'supplies': echo '#FFF3E0'; break;
                                    default: echo '#f5f5f5';
                                }
                            ?>;
                            color: 
                            <?php
                                switch($category['type']) {
                                    case 'livestock': echo '#2E7D32'; break;
                                    case 'equipment': echo '#1565C0'; break;
                                    case 'crops': echo '#558B2F'; break;
                                    case 'supplies': echo '#EF6C00'; break;
                                    default: echo '#757575';
                                }
                            ?>;">
                            <?php echo ucfirst(htmlspecialchars($category['type'])); ?>
                        </span>
                    </td>
                    <td><?php echo htmlspecialchars($category['description']); ?></td>
                    <td><?php echo $items_count; ?></td>
                    <td>
                        <div class="table-actions">
                            <a href="index.php?page=inventory&category_id=<?php echo $category['id']; ?>" class="btn btn-small btn-info">
                                <i class="fas fa-list"></i>
                            </a>
                            <button class="btn btn-small btn-primary" data-modal-target="editCategoryModal<?php echo $category['id']; ?>">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="btn btn-small btn-danger" onclick="confirmDelete(<?php echo $category['id']; ?>, 'category')">
                                <i class="fas fa-trash"></i>
                            </button>
                            
                            <!-- Hidden delete form -->
                            <form id="delete-category-<?php echo $category['id']; ?>" action="index.php?page=categories" method="POST" style="display: none;">
                                <input type="hidden" name="delete_category" value="1">
                                <input type="hidden" name="category_id" value="<?php echo $category['id']; ?>">
                            </form>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>No categories found.</p>
    <?php endif; ?>
</div>

<!-- Add Category Modal -->
<div class="modal-overlay" id="addCategoryModal">
    <div class="modal">
        <div class="modal-header">
            <h3 class="modal-title">Add New Category</h3>
            <button class="modal-close" data-modal-close>&times;</button>
        </div>
        <div class="modal-body">
            <form action="index.php?page=categories" method="POST" data-validate>
                <input type="hidden" name="add_category" value="1">
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="name">Category Name</label>
                        <input type="text" id="name" name="name" class="form-control" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="type">Category Type</label>
                        <select id="type" name="type" class="form-control" required>
                            <option value="">Select Type</option>
                            <option value="livestock">Livestock</option>
                            <option value="equipment">Equipment</option>
                            <option value="crops">Crops</option>
                            <option value="supplies">Supplies</option>
                        </select>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group" style="width: 100%;">
                        <label for="description">Description</label>
                        <textarea id="description" name="description" class="form-control"></textarea>
                    </div>
                </div>
                
                <div class="form-actions">
                    <button type="button" class="btn btn-outline" data-modal-close>Cancel</button>
                    <button type="submit" class="btn btn-primary">Add Category</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Category Modals -->
<?php foreach ($categories as $category): ?>
    <div class="modal-overlay" id="editCategoryModal<?php echo $category['id']; ?>">
        <div class="modal">
            <div class="modal-header">
                <h3 class="modal-title">Edit Category</h3>
                <button class="modal-close" data-modal-close>&times;</button>
            </div>
            <div class="modal-body">
                <form action="index.php?page=categories" method="POST" data-validate>
                    <input type="hidden" name="update_category" value="1">
                    <input type="hidden" name="category_id" value="<?php echo $category['id']; ?>">
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="edit_name_<?php echo $category['id']; ?>">Category Name</label>
                            <input type="text" id="edit_name_<?php echo $category['id']; ?>" name="name" class="form-control" value="<?php echo htmlspecialchars($category['name']); ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="edit_type_<?php echo $category['id']; ?>">Category Type</label>
                            <select id="edit_type_<?php echo $category['id']; ?>" name="type" class="form-control" required>
                                <option value="livestock" <?php echo ($category['type'] == 'livestock') ? 'selected' : ''; ?>>Livestock</option>
                                <option value="equipment" <?php echo ($category['type'] == 'equipment') ? 'selected' : ''; ?>>Equipment</option>
                                <option value="crops" <?php echo ($category['type'] == 'crops') ? 'selected' : ''; ?>>Crops</option>
                                <option value="supplies" <?php echo ($category['type'] == 'supplies') ? 'selected' : ''; ?>>Supplies</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group" style="width: 100%;">
                            <label for="edit_description_<?php echo $category['id']; ?>">Description</label>
                            <textarea id="edit_description_<?php echo $category['id']; ?>" name="description" class="form-control"><?php echo htmlspecialchars($category['description']); ?></textarea>
                        </div>
                    </div>
                    
                    <div class="form-actions">
                        <button type="button" class="btn btn-outline" data-modal-close>Cancel</button>
                        <button type="submit" class="btn btn-primary">Update Category</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php endforeach; ?>