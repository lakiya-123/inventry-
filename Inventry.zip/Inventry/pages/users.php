<?php
// Check if user has admin privileges
if (!has_permission('admin')) {
    echo '<div class="alert alert-danger">You do not have permission to access this page.</div>';
    exit();
}

// Check if we need to process any actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Add new user
    if (isset($_POST['add_user'])) {
        $username = sanitize_input($_POST['username']);
        $password = $_POST['password'];
        $full_name = sanitize_input($_POST['full_name']);
        $email = sanitize_input($_POST['email']);
        $role = sanitize_input($_POST['role']);
        
        // Check if username already exists
        $stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $_SESSION['error_message'] = "Username already exists. Please choose a different username.";
        } else {
            // Hash password
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            
            // Insert into database
            $stmt = $conn->prepare("INSERT INTO users (username, password, full_name, email, role) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("sssss", $username, $hashed_password, $full_name, $email, $role);
            
            if ($stmt->execute()) {
                $user_id = $conn->insert_id;
                
                // Log activity
                log_activity($_SESSION['user_id'], 'add', $user_id, 'user', "Added user: $username");
                
                // Set success message
                $_SESSION['success_message'] = "User added successfully!";
            } else {
                $_SESSION['error_message'] = "Error adding user: " . $conn->error;
            }
        }
        
        // Redirect to prevent form resubmission
        header("Location: index.php?page=users");
        exit();
    }
    
    // Update user
    if (isset($_POST['update_user'])) {
        $user_id = (int)$_POST['user_id'];
        $full_name = sanitize_input($_POST['full_name']);
        $email = sanitize_input($_POST['email']);
        $role = sanitize_input($_POST['role']);
        $password = $_POST['password'];
        
        // Start building the update query
        $sql = "UPDATE users SET full_name = ?, email = ?, role = ?";
        $params = array($full_name, $email, $role);
        $types = "sss";
        
        // Add password to update if provided
        if (!empty($password)) {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $sql .= ", password = ?";
            $params[] = $hashed_password;
            $types .= "s";
        }
        
        // Finish the query
        $sql .= " WHERE id = ?";
        $params[] = $user_id;
        $types .= "i";
        
        // Prepare and execute the statement
        $stmt = $conn->prepare($sql);
        $stmt->bind_param($types, ...$params);
        
        if ($stmt->execute()) {
            // Log activity
            log_activity($_SESSION['user_id'], 'update', $user_id, 'user', "Updated user information");
            
            // Set success message
            $_SESSION['success_message'] = "User updated successfully!";
        } else {
            $_SESSION['error_message'] = "Error updating user: " . $conn->error;
        }
        
        // Redirect to prevent form resubmission
        header("Location: index.php?page=users");
        exit();
    }
    
    // Delete user
    if (isset($_POST['delete_user'])) {
        $user_id = (int)$_POST['user_id'];
        
        // Cannot delete yourself
        if ($user_id == $_SESSION['user_id']) {
            $_SESSION['error_message'] = "You cannot delete your own account.";
        } else {
            // Get user details for logging
            $stmt = $conn->prepare("SELECT username FROM users WHERE id = ?");
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $result = $stmt->get_result();
            $user = $result->fetch_assoc();
            
            if ($user) {
                // Delete user from database
                $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
                $stmt->bind_param("i", $user_id);
                
                if ($stmt->execute()) {
                    // Log activity
                    log_activity($_SESSION['user_id'], 'delete', $user_id, 'user', "Deleted user: {$user['username']}");
                    
                    // Set success message
                    $_SESSION['success_message'] = "User deleted successfully!";
                } else {
                    $_SESSION['error_message'] = "Error deleting user: " . $conn->error;
                }
            } else {
                $_SESSION['error_message'] = "User not found.";
            }
        }
        
        // Redirect to prevent form resubmission
        header("Location: index.php?page=users");
        exit();
    }
}

// Get all users
$result = $conn->query("SELECT * FROM users ORDER BY username");
$users = [];

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $users[] = $row;
    }
}
?>

<h1>User Management</h1>

<!-- Success and Error Messages -->
<?php if (isset($_SESSION['success_message'])): ?>
    <div class="alert alert-success">
        <?php 
            echo $_SESSION['success_message']; 
            unset($_SESSION['success_message']);
        ?>
    </div>
<?php endif; ?>

<?php if (isset($_SESSION['error_message'])): ?>
    <div class="alert alert-danger">
        <?php 
            echo $_SESSION['error_message']; 
            unset($_SESSION['error_message']);
        ?>
    </div>
<?php endif; ?>

<!-- Users Table -->
<div class="page-header">
    <h2>Users</h2>
    <button class="btn btn-primary" data-modal-target="addUserModal">
        <i class="fas fa-plus"></i> Add New User
    </button>
</div>

<div class="data-container">
    <?php if (count($users) > 0): ?>
        <table class="data-table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Username</th>
                    <th>Full Name</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Last Login</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $index => $user): ?>
                    <?php
                        // Get last login time
                        $stmt = $conn->prepare("SELECT created_at FROM activity_log WHERE user_id = ? AND action = 'login' ORDER BY created_at DESC LIMIT 1");
                        $stmt->bind_param("i", $user['id']);
                        $stmt->execute();
                        $result = $stmt->get_result();
                        $last_login = $result->num_rows > 0 ? $result->fetch_assoc()['created_at'] : 'Never';
                    ?>
                <tr>
                    <td><?php echo $index + 1; ?></td>
                    <td><?php echo htmlspecialchars($user['username']); ?></td>
                    <td><?php echo htmlspecialchars($user['full_name']); ?></td>
                    <td><?php echo htmlspecialchars($user['email']); ?></td>
                    <td>
                        <span class="item-status" style="background-color: 
                            <?php
                                switch($user['role']) {
                                    case 'admin': echo '#E8F5E9'; break;
                                    case 'manager': echo '#E3F2FD'; break;
                                    case 'staff': echo '#FFF3E0'; break;
                                    default: echo '#f5f5f5';
                                }
                            ?>;
                            color: 
                            <?php
                                switch($user['role']) {
                                    case 'admin': echo '#2E7D32'; break;
                                    case 'manager': echo '#1565C0'; break;
                                    case 'staff': echo '#EF6C00'; break;
                                    default: echo '#757575';
                                }
                            ?>;">
                            <?php echo ucfirst(htmlspecialchars($user['role'])); ?>
                        </span>
                    </td>
                    <td>
                        <?php 
                            if ($last_login != 'Never') {
                                echo date('M d, Y H:i', strtotime($last_login));
                            } else {
                                echo 'Never';
                            }
                        ?>
                    </td>
                    <td>
                        <div class="table-actions">
                            <button class="btn btn-small btn-primary" data-modal-target="editUserModal<?php echo $user['id']; ?>">
                                <i class="fas fa-edit"></i>
                            </button>
                            <?php if ($user['id'] != $_SESSION['user_id']): ?>
                            <button class="btn btn-small btn-danger" onclick="confirmDelete(<?php echo $user['id']; ?>, 'user')">
                                <i class="fas fa-trash"></i>
                            </button>
                            
                            <!-- Hidden delete form -->
                            <form id="delete-user-<?php echo $user['id']; ?>" action="index.php?page=users" method="POST" style="display: none;">
                                <input type="hidden" name="delete_user" value="1">
                                <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                            </form>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>No users found.</p>
    <?php endif; ?>
</div>

<!-- Add User Modal -->
<div class="modal-overlay" id="addUserModal">
    <div class="modal">
        <div class="modal-header">
            <h3 class="modal-title">Add New User</h3>
            <button class="modal-close" data-modal-close>&times;</button>
        </div>
        <div class="modal-body">
            <form action="index.php?page=users" method="POST" data-validate>
                <input type="hidden" name="add_user" value="1">
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="username">Username</label>
                        <input type="text" id="username" name="username" class="form-control" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" id="password" name="password" class="form-control" required>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="full_name">Full Name</label>
                        <input type="text" id="full_name" name="full_name" class="form-control" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" id="email" name="email" class="form-control" required>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="role">Role</label>
                        <select id="role" name="role" class="form-control" required>
                            <option value="admin">Administrator</option>
                            <option value="manager">Manager</option>
                            <option value="staff">Staff</option>
                        </select>
                    </div>
                </div>
                
                <div class="form-actions">
                    <button type="button" class="btn btn-outline" data-modal-close>Cancel</button>
                    <button type="submit" class="btn btn-primary">Add User</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit User Modals -->
<?php foreach ($users as $user): ?>
    <div class="modal-overlay" id="editUserModal<?php echo $user['id']; ?>">
        <div class="modal">
            <div class="modal-header">
                <h3 class="modal-title">Edit User</h3>
                <button class="modal-close" data-modal-close>&times;</button>
            </div>
            <div class="modal-body">
                <form action="index.php?page=users" method="POST" data-validate>
                    <input type="hidden" name="update_user" value="1">
                    <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label>Username</label>
                            <input type="text" class="form-control" value="<?php echo htmlspecialchars($user['username']); ?>" disabled>
                            <small class="text-muted">Username cannot be changed</small>
                        </div>
                        
                        <div class="form-group">
                            <label for="password_<?php echo $user['id']; ?>">Password</label>
                            <input type="password" id="password_<?php echo $user['id']; ?>" name="password" class="form-control" placeholder="Leave blank to keep current password">
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="full_name_<?php echo $user['id']; ?>">Full Name</label>
                            <input type="text" id="full_name_<?php echo $user['id']; ?>" name="full_name" class="form-control" value="<?php echo htmlspecialchars($user['full_name']); ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="email_<?php echo $user['id']; ?>">Email</label>
                            <input type="email" id="email_<?php echo $user['id']; ?>" name="email" class="form-control" value="<?php echo htmlspecialchars($user['email']); ?>" required>
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="role_<?php echo $user['id']; ?>">Role</label>
                            <select id="role_<?php echo $user['id']; ?>" name="role" class="form-control" required>
                                <option value="admin" <?php echo ($user['role'] == 'admin') ? 'selected' : ''; ?>>Administrator</option>
                                <option value="manager" <?php echo ($user['role'] == 'manager') ? 'selected' : ''; ?>>Manager</option>
                                <option value="staff" <?php echo ($user['role'] == 'staff') ? 'selected' : ''; ?>>Staff</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-actions">
                        <button type="button" class="btn btn-outline" data-modal-close>Cancel</button>
                        <button type="submit" class="btn btn-primary">Update User</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php endforeach; ?>