<?php
// Check if we need to generate a report
$report_type = isset($_GET['report_type']) ? sanitize_input($_GET['report_type']) : null;
$category_id = isset($_GET['category_id']) ? (int)$_GET['category_id'] : null;
$status = isset($_GET['status']) ? sanitize_input($_GET['status']) : null;
$date_from = isset($_GET['date_from']) ? sanitize_input($_GET['date_from']) : null;
$date_to = isset($_GET['date_to']) ? sanitize_input($_GET['date_to']) : null;

// Get all categories for filter
$categories = get_categories();

// Initialize variables
$report_data = [];
$report_title = '';

// Generate report based on type
if ($report_type) {
    switch ($report_type) {
        case 'inventory_value':
            $report_title = 'Inventory Value Report';
            
            // Base query
            $query = "SELECT c.name as category_name, c.type as category_type, 
                     SUM(i.quantity) as total_quantity, 
                     SUM(i.quantity * i.price) as total_value
                     FROM inventory i
                     JOIN categories c ON i.category_id = c.id
                     WHERE 1=1";
            
            // Add filters
            if ($category_id) {
                $query .= " AND i.category_id = $category_id";
            }
            
            if ($status) {
                $query .= " AND i.status = '$status'";
            }
            
            // Group by category
            $query .= " GROUP BY c.id
                       ORDER BY total_value DESC";
            
            $result = $conn->query($query);
            
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $report_data[] = $row;
                }
            }
            break;
            
        case 'low_stock':
            $report_title = 'Low Stock Report';
            
            // Get low stock items
            $report_data = get_inventory(null, null, 'low_stock');
            break;
            
        case 'expiry':
            $report_title = 'Expiry Report';
            
            // Base query for items with expiry dates
            $query = "SELECT i.*, c.name as category_name, c.type as category_type
                     FROM inventory i
                     JOIN categories c ON i.category_id = c.id
                     WHERE i.expiry_date IS NOT NULL";
            
            // Add date range filter
            if ($date_from) {
                $query .= " AND i.expiry_date >= '$date_from'";
            }
            
            if ($date_to) {
                $query .= " AND i.expiry_date <= '$date_to'";
            } else {
                // Default show items expiring in next 30 days if no date range
                if (!$date_from) {
                    $query .= " AND i.expiry_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)";
                }
            }
            
            $query .= " ORDER BY i.expiry_date ASC";
            
            $result = $conn->query($query);
            
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $report_data[] = $row;
                }
            }
            break;
            
        case 'activity':
            $report_title = 'Activity Report';
            
            // Base query
            $query = "SELECT a.*, u.username, u.full_name
                     FROM activity_log a
                     JOIN users u ON a.user_id = u.id
                     WHERE 1=1";
            
            // Add date range filter
            if ($date_from) {
                $query .= " AND DATE(a.created_at) >= '$date_from'";
            }
            
            if ($date_to) {
                $query .= " AND DATE(a.created_at) <= '$date_to'";
            }
            
            $query .= " ORDER BY a.created_at DESC";
            
            $result = $conn->query($query);
            
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $report_data[] = $row;
                }
            }
            break;

        case 'summary':
            $report_title = 'Summary Report';
            
            // Initialize summary data structure
            $summary = [
                'category_stats' => [],
                'inventory_stats' => [],
                'transaction_stats' => [],
                'stock_status_breakdown' => [],
                'recent_transactions' => []
            ];
            
            // Date range for transactions
            $date_condition = " 1=1";
            if ($date_from) {
                $date_condition .= " AND DATE(created_at) >= '$date_from'";
            }
            if ($date_to) {
                $date_condition .= " AND DATE(created_at) <= '$date_to'";
            }
            
            // 1. Category Statistics
            $query = "SELECT 
                        COUNT(*) as total_categories,
                        COUNT(DISTINCT type) as unique_types 
                      FROM categories";
            $result = $conn->query($query);
            if ($result->num_rows > 0) {
                $summary['category_stats'] = $result->fetch_assoc();
            }
            
            // Category breakdown by type
            $query = "SELECT 
                        type, 
                        COUNT(*) as count 
                      FROM categories 
                      GROUP BY type 
                      ORDER BY count DESC";
            $result = $conn->query($query);
            $summary['category_types'] = [];
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $summary['category_types'][] = $row;
                }
            }
            
            // 2. Inventory Statistics
            $query = "SELECT 
                        COUNT(*) as total_items,
                        SUM(quantity) as total_quantity,
                        SUM(quantity * price) as total_value,
                        AVG(price) as average_price,
                        COUNT(DISTINCT category_id) as categories_in_use
                      FROM inventory";
            $result = $conn->query($query);
            if ($result->num_rows > 0) {
                $summary['inventory_stats'] = $result->fetch_assoc();
            }
            
            // Stock status breakdown
            $query = "SELECT 
                        status, 
                        COUNT(*) as count,
                        SUM(quantity) as total_quantity,
                        SUM(quantity * price) as total_value
                      FROM inventory 
                      GROUP BY status";
            $result = $conn->query($query);
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $summary['stock_status_breakdown'][] = $row;
                }
            }
            
            // Top 5 most valuable categories
            $query = "SELECT 
                        c.name as category_name,
                        c.type as category_type,
                        COUNT(i.id) as item_count,
                        SUM(i.quantity) as total_quantity,
                        SUM(i.quantity * i.price) as total_value
                      FROM inventory i
                      JOIN categories c ON i.category_id = c.id
                      GROUP BY i.category_id
                      ORDER BY total_value DESC
                      LIMIT 5";
            $result = $conn->query($query);
            $summary['top_categories'] = [];
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $summary['top_categories'][] = $row;
                }
            }
            
            // 3. Transaction Statistics
            $query = "SELECT 
                        COUNT(*) as total_transactions,
                        SUM(CASE WHEN transaction_type = 'in' THEN quantity ELSE 0 END) as total_in,
                        SUM(CASE WHEN transaction_type = 'out' THEN quantity ELSE 0 END) as total_out
                      FROM inventory_transactions
                      WHERE $date_condition";
            $result = $conn->query($query);
            if ($result->num_rows > 0) {
                $summary['transaction_stats'] = $result->fetch_assoc();
            }
            
            // Transaction breakdown by type
            $query = "SELECT 
                        transaction_type,
                        COUNT(*) as count,
                        SUM(quantity) as total_quantity
                      FROM inventory_transactions
                      WHERE $date_condition
                      GROUP BY transaction_type";
            $result = $conn->query($query);
            $summary['transaction_types'] = [];
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $summary['transaction_types'][] = $row;
                }
            }
            
            // Recent transactions - last 10
            $query = "SELECT 
                        t.*,
                        i.name as item_name,
                        u.username,
                        c.name as category_name
                      FROM inventory_transactions t
                      JOIN inventory i ON t.inventory_id = i.id
                      JOIN users u ON t.user_id = u.id
                      JOIN categories c ON i.category_id = c.id
                      WHERE $date_condition
                      ORDER BY t.created_at DESC
                      LIMIT 10";
            $result = $conn->query($query);
            $summary['recent_transactions'] = [];
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $summary['recent_transactions'][] = $row;
                }
            }
            
            // Assign the summary to report_data
            $report_data = $summary;
            break;
    }
    
    // Log report generation
    log_activity($_SESSION['user_id'], 'generate', 0, 'report', "Generated $report_title");
}
?>

<style>
/* Summary Report Styling */
.summary-section {
    margin-bottom: 25px;
    background-color: #fff;
    border-radius: 5px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
    padding: 15px;
}

.summary-section h3 {
    margin-top: 0;
    padding-bottom: 10px;
    border-bottom: 1px solid #eee;
    font-size: 18px;
    color: #333;
}

.summary-cards {
    display: flex;
    flex-wrap: wrap;
    gap: 15px;
    margin-bottom: 15px;
}

.summary-card {
    flex: 1;
    min-width: 200px;
    display: flex;
    align-items: center;
    padding: 15px;
    background: #f9f9f9;
    border-left: 4px solid var(--primary-color);
    border-radius: 4px;
}

.summary-icon {
    font-size: 24px;
    color: var(--primary-color);
    margin-right: 15px;
    width: 40px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    background-color: rgba(var(--primary-color-rgb), 0.1);
    border-radius: 50%;
}

.summary-data {
    flex: 1;
}

.summary-value {
    font-size: 20px;
    font-weight: bold;
    color: #333;
}

.summary-label {
    font-size: 13px;
    color: #666;
    margin-top: 4px;
}

.transaction-in {
    background-color: var(--success-color);
    color: white;
    padding: 3px 8px;
    border-radius: 3px;
    font-size: 12px;
    font-weight: bold;
}

.transaction-out {
    background-color: var(--danger-color);
    color: white;
    padding: 3px 8px;
    border-radius: 3px;
    font-size: 12px;
    font-weight: bold;
}

/* Responsive adjustments */
@media (max-width: 768px) {
    .summary-cards {
        flex-direction: column;
    }
    
    .summary-card {
        width: 100%;
    }
}
</style>

<h1>Reports</h1>

<!-- Report Filters -->
<div class="filter-container">
    <form action="index.php" method="GET" class="filter-form">
        <input type="hidden" name="page" value="reports">
        
        <div class="filter-group">
            <label for="report_type">Report Type</label>
            <select name="report_type" id="report_type" class="filter-input" required>
                <option value="">Select Report Type</option>
                <option value="summary" <?php echo ($report_type == 'summary') ? 'selected' : ''; ?>>Summary Report</option>
                <option value="inventory_value" <?php echo ($report_type == 'inventory_value') ? 'selected' : ''; ?>>Inventory Value</option>
                <option value="low_stock" <?php echo ($report_type == 'low_stock') ? 'selected' : ''; ?>>Low Stock Items</option>
                <option value="expiry" <?php echo ($report_type == 'expiry') ? 'selected' : ''; ?>>Expiry Dates</option>
                <option value="activity" <?php echo ($report_type == 'activity') ? 'selected' : ''; ?>>Activity Log</option>
            </select>
        </div>
        
        <div class="filter-group category-filter" style="<?php echo in_array($report_type, ['inventory_value', 'low_stock']) ? '' : 'display: none;'; ?>">
            <label for="category_id">Category</label>
            <select name="category_id" id="category_id" class="filter-input">
                <option value="">All Categories</option>
                <?php foreach ($categories as $category): ?>
                <option value="<?php echo $category['id']; ?>" <?php echo ($category_id == $category['id']) ? 'selected' : ''; ?>>
                    <?php echo htmlspecialchars($category['name']); ?> (<?php echo htmlspecialchars($category['type']); ?>)
                </option>
                <?php endforeach; ?>
            </select>
        </div>
        
        <div class="filter-group status-filter" style="<?php echo in_array($report_type, ['inventory_value']) ? '' : 'display: none;'; ?>">
            <label for="status">Status</label>
            <select name="status" id="status" class="filter-input">
                <option value="">All Status</option>
                <option value="available" <?php echo ($status == 'available') ? 'selected' : ''; ?>>Available</option>
                <option value="low_stock" <?php echo ($status == 'low_stock') ? 'selected' : ''; ?>>Low Stock</option>
                <option value="out_of_stock" <?php echo ($status == 'out_of_stock') ? 'selected' : ''; ?>>Out of Stock</option>
                <option value="expired" <?php echo ($status == 'expired') ? 'selected' : ''; ?>>Expired</option>
            </select>
        </div>
        
        <div class="filter-group date-filter" style="<?php echo in_array($report_type, ['expiry', 'activity', 'summary']) ? '' : 'display: none;'; ?>">
            <label for="date_from">From Date</label>
            <input type="date" name="date_from" id="date_from" class="filter-input" value="<?php echo $date_from; ?>">
        </div>
        
        <div class="filter-group date-filter" style="<?php echo in_array($report_type, ['expiry', 'activity', 'summary']) ? '' : 'display: none;'; ?>">
            <label for="date_to">To Date</label>
            <input type="date" name="date_to" id="date_to" class="filter-input" value="<?php echo $date_to; ?>">
        </div>
        
        <div class="filter-buttons">
            <button type="submit" class="btn btn-primary">Generate Report</button>
            <a href="index.php?page=reports" class="btn btn-outline">Reset</a>
        </div>
    </form>
</div>

<!-- Report Output -->
<?php if ($report_type && !empty($report_data)): ?>
    <div class="report-card">
        <div class="page-header">
            <h2><?php echo $report_title; ?></h2>
            <div>
                <button class="btn btn-info" onclick="printReport()">
                    <i class="fas fa-print"></i> Print
                </button>
                <button class="btn btn-success" onclick="exportToCSV('reportTable', '<?php echo strtolower(str_replace(' ', '_', $report_title)); ?>.csv')">
                    <i class="fas fa-download"></i> Export to CSV
                </button>
            </div>
        </div>
        
        <div class="report-meta">
            <p>
                <strong>Date Generated:</strong> <?php echo date('M d, Y H:i'); ?><br>
                <strong>Generated By:</strong> <?php echo $_SESSION['user_name']; ?>
            </p>
            
            <?php if ($category_id): ?>
                <?php $selected_category = get_category($category_id); ?>
                <p><strong>Category:</strong> <?php echo htmlspecialchars($selected_category['name']); ?></p>
            <?php endif; ?>
            
            <?php if ($status): ?>
                <p><strong>Status:</strong> <?php echo ucwords(str_replace('_', ' ', $status)); ?></p>
            <?php endif; ?>
            
            <?php if ($date_from): ?>
                <p><strong>From Date:</strong> <?php echo date('M d, Y', strtotime($date_from)); ?></p>
            <?php endif; ?>
            
            <?php if ($date_to): ?>
                <p><strong>To Date:</strong> <?php echo date('M d, Y', strtotime($date_to)); ?></p>
            <?php endif; ?>
        </div>
        
        <div class="data-container">
            <?php if ($report_type == 'summary'): ?>
                <!-- Summary Report Layout with Dashboard-like Sections -->
                <div class="summary-report">
                    <!-- Overview Cards -->
                    <div class="summary-section">
                        <h3>Inventory Overview</h3>
                        <div class="summary-cards">
                            <div class="summary-card">
                                <div class="summary-icon"><i class="fas fa-boxes"></i></div>
                                <div class="summary-data">
                                    <div class="summary-value"><?php echo number_format($report_data['inventory_stats']['total_items']); ?></div>
                                    <div class="summary-label">Total Items</div>
                                </div>
                            </div>
                            <div class="summary-card">
                                <div class="summary-icon"><i class="fas fa-layer-group"></i></div>
                                <div class="summary-data">
                                    <div class="summary-value"><?php echo number_format($report_data['inventory_stats']['total_quantity']); ?></div>
                                    <div class="summary-label">Total Quantity</div>
                                </div>
                            </div>
                            <div class="summary-card">
                                <div class="summary-icon"><i class="fas fa-dollar-sign"></i></div>
                                <div class="summary-data">
                                    <div class="summary-value"><?php echo format_currency($report_data['inventory_stats']['total_value']); ?></div>
                                    <div class="summary-label">Total Value</div>
                                </div>
                            </div>
                            <div class="summary-card">
                                <div class="summary-icon"><i class="fas fa-tags"></i></div>
                                <div class="summary-data">
                                    <div class="summary-value"><?php echo number_format($report_data['category_stats']['total_categories']); ?></div>
                                    <div class="summary-label">Categories</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Stock Status Section -->
                    <div class="summary-section">
                        <h3>Stock Status Breakdown</h3>
                        <table class="data-table" id="stockStatusTable">
                            <thead>
                                <tr>
                                    <th>Status</th>
                                    <th>Item Count</th>
                                    <th>Quantity</th>
                                    <th>Total Value</th>
                                    <th>% of Inventory Value</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                    foreach ($report_data['stock_status_breakdown'] as $status): 
                                    $percentage = ($report_data['inventory_stats']['total_value'] > 0) ? 
                                        ($status['total_value'] / $report_data['inventory_stats']['total_value']) * 100 : 0;
                                ?>
                                <tr>
                                    <td>
                                        <span class="item-status status-<?php echo $status['status']; ?>">
                                            <?php echo ucwords(str_replace('_', ' ', $status['status'])); ?>
                                        </span>
                                    </td>
                                    <td><?php echo number_format($status['count']); ?></td>
                                    <td><?php echo number_format($status['total_quantity']); ?></td>
                                    <td><?php echo format_currency($status['total_value']); ?></td>
                                    <td><?php echo number_format($percentage, 1); ?>%</td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <!-- Top Categories By Value -->
                    <div class="summary-section">
                        <h3>Top 5 Most Valuable Categories</h3>
                        <table class="data-table" id="topCategoriesTable">
                            <thead>
                                <tr>
                                    <th>Category Name</th>
                                    <th>Type</th>
                                    <th>Item Count</th>
                                    <th>Total Quantity</th>
                                    <th>Total Value</th>
                                    <th>% of Total Value</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                    foreach ($report_data['top_categories'] as $category): 
                                    $percentage = ($report_data['inventory_stats']['total_value'] > 0) ? 
                                        ($category['total_value'] / $report_data['inventory_stats']['total_value']) * 100 : 0;
                                ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($category['category_name']); ?></td>
                                    <td><?php echo ucfirst(htmlspecialchars($category['category_type'])); ?></td>
                                    <td><?php echo number_format($category['item_count']); ?></td>
                                    <td><?php echo number_format($category['total_quantity']); ?></td>
                                    <td><?php echo format_currency($category['total_value']); ?></td>
                                    <td><?php echo number_format($percentage, 1); ?>%</td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <!-- Transaction Summary -->
                    <div class="summary-section">
                        <h3>Transaction Summary<?php echo ($date_from || $date_to) ? ' (Selected Period)' : ''; ?></h3>
                        <div class="summary-cards">
                            <div class="summary-card">
                                <div class="summary-icon"><i class="fas fa-exchange-alt"></i></div>
                                <div class="summary-data">
                                    <div class="summary-value"><?php echo number_format($report_data['transaction_stats']['total_transactions']); ?></div>
                                    <div class="summary-label">Total Transactions</div>
                                </div>
                            </div>
                            <div class="summary-card">
                                <div class="summary-icon"><i class="fas fa-arrow-circle-down"></i></div>
                                <div class="summary-data">
                                    <div class="summary-value"><?php echo number_format($report_data['transaction_stats']['total_in']); ?></div>
                                    <div class="summary-label">Total Incoming</div>
                                </div>
                            </div>
                            <div class="summary-card">
                                <div class="summary-icon"><i class="fas fa-arrow-circle-up"></i></div>
                                <div class="summary-data">
                                    <div class="summary-value"><?php echo number_format($report_data['transaction_stats']['total_out']); ?></div>
                                    <div class="summary-label">Total Outgoing</div>
                                </div>
                            </div>
                            <div class="summary-card">
                                <div class="summary-icon"><i class="fas fa-balance-scale"></i></div>
                                <div class="summary-data">
                                    <div class="summary-value"><?php echo number_format($report_data['transaction_stats']['total_in'] - $report_data['transaction_stats']['total_out']); ?></div>
                                    <div class="summary-label">Net Change</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Recent Transactions -->
                    <div class="summary-section">
                        <h3>Retrieve Transactions</h3>
                        <table class="data-table" id="recentTransactionsTable">
                            <thead>
                                <tr>
                                    <th>Date & Time</th>
                                    <th>Item</th>
                                    <th>Category</th>
                                    <th>Type</th>
                                    <th>Quantity</th>
                                    <th>Unit</th>
                                    <th>User</th>
                                    <th>Notes</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($report_data['recent_transactions'] as $transaction): ?>
                                <tr>
                                    <td><?php echo date('M d, Y H:i', strtotime($transaction['created_at'])); ?></td>
                                    <td><?php echo htmlspecialchars($transaction['item_name']); ?></td>
                                    <td><?php echo htmlspecialchars($transaction['category_name']); ?></td>
                                    <td>
                                        <?php if ($transaction['transaction_type'] == 'in'): ?>
                                            <span class="transaction-in">IN</span>
                                        <?php else: ?>
                                            <span class="transaction-out">OUT</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo number_format($transaction['quantity']); ?></td>
                                    <td><?php echo htmlspecialchars($transaction['unit']); ?></td>
                                    <td><?php echo htmlspecialchars($transaction['username']); ?></td>
                                    <td><?php echo htmlspecialchars($transaction['notes']); ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <!-- Category Type Breakdown -->
                    <div class="summary-section">
                        <h3>Category Types</h3>
                        <table class="data-table" id="categoryTypesTable">
                            <thead>
                                <tr>
                                    <th>Category Type</th>
                                    <th>Count</th>
                                    <th>% of Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                    foreach ($report_data['category_types'] as $type): 
                                    $percentage = ($report_data['category_stats']['total_categories'] > 0) ? 
                                        ($type['count'] / $report_data['category_stats']['total_categories']) * 100 : 0;
                                ?>
                                <tr>
                                    <td><?php echo ucfirst(htmlspecialchars($type['type'])); ?></td>
                                    <td><?php echo number_format($type['count']); ?></td>
                                    <td><?php echo number_format($percentage, 1); ?>%</td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php elseif ($report_type == 'inventory_value'): ?>
                <table class="data-table" id="reportTable">
                    <thead>
                        <tr>
                            <th>Category</th>
                            <th>Type</th>
                            <th>Total Quantity</th>
                            <th>Total Value</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                            $grand_total = 0;
                            foreach ($report_data as $row): 
                            $grand_total += $row['total_value'];
                        ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['category_name']); ?></td>
                            <td><?php echo ucfirst(htmlspecialchars($row['category_type'])); ?></td>
                            <td><?php echo $row['total_quantity']; ?></td>
                            <td><?php echo format_currency($row['total_value']); ?></td>
                        </tr>
                        <?php endforeach; ?>
                        <tr>
                            <td colspan="3" style="text-align: right;"><strong>Grand Total:</strong></td>
                            <td><strong><?php echo format_currency($grand_total); ?></strong></td>
                        </tr>
                    </tbody>
                </table>
            <?php elseif ($report_type == 'low_stock'): ?>
                <table class="data-table" id="reportTable">
                    <thead>
                        <tr>
                            <th>Item Name</th>
                            <th>Category</th>
                            <th>Current Quantity</th>
                            <th>Min Stock Level</th>
                            <th>Reorder Amount</th>
                            <th>Unit</th>
                            <th>Unit Price</th>
                            <th>Reorder Cost</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                            $total_reorder_cost = 0;
                            foreach ($report_data as $row): 
                            $reorder_amount = $row['min_stock_level'] - $row['quantity'] + 5; // Add buffer of 5
                            $reorder_cost = $reorder_amount * $row['price'];
                            $total_reorder_cost += $reorder_cost;
                        ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['name']); ?></td>
                            <td><?php echo htmlspecialchars($row['category_name']); ?></td>
                            <td><?php echo $row['quantity']; ?></td>
                            <td><?php echo $row['min_stock_level']; ?></td>
                            <td><?php echo $reorder_amount; ?></td>
                            <td><?php echo htmlspecialchars($row['unit']); ?></td>
                            <td><?php echo format_currency($row['price']); ?></td>
                            <td><?php echo format_currency($reorder_cost); ?></td>
                        </tr>
                        <?php endforeach; ?>
                        <tr>
                            <td colspan="7" style="text-align: right;"><strong>Total Reorder Cost:</strong></td>
                            <td><strong><?php echo format_currency($total_reorder_cost); ?></strong></td>
                        </tr>
                    </tbody>
                </table>
            <?php elseif ($report_type == 'expiry'): ?>
                <table class="data-table" id="reportTable">
                    <thead>
                        <tr>
                            <th>Item Name</th>
                            <th>Category</th>
                            <th>Quantity</th>
                            <th>Unit</th>
                            <th>Expiry Date</th>
                            <th>Days Until Expiry</th>
                            <th>Status</th>
                            <th>Value</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                            $total_expiry_value = 0;
                            foreach ($report_data as $row): 
                            $days_until_expiry = (strtotime($row['expiry_date']) - time()) / (60 * 60 * 24);
                            $days_until_expiry = round($days_until_expiry);
                            $item_value = $row['quantity'] * $row['price'];
                            $total_expiry_value += $item_value;
                        ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['name']); ?></td>
                            <td><?php echo htmlspecialchars($row['category_name']); ?></td>
                            <td><?php echo $row['quantity']; ?></td>
                            <td><?php echo htmlspecialchars($row['unit']); ?></td>
                            <td><?php echo date('M d, Y', strtotime($row['expiry_date'])); ?></td>
                            <td>
                                <?php 
                                    if ($days_until_expiry < 0) {
                                        echo '<span style="color: var(--danger-color);">Expired (' . abs($days_until_expiry) . ' days ago)</span>';
                                    } else if ($days_until_expiry <= 7) {
                                        echo '<span style="color: var(--danger-color);">' . $days_until_expiry . ' days</span>';
                                    } else if ($days_until_expiry <= 30) {
                                        echo '<span style="color: var(--warning-color);">' . $days_until_expiry . ' days</span>';
                                    } else {
                                        echo $days_until_expiry . ' days';
                                    }
                                ?>
                            </td>
                            <td>
                                <span class="item-status status-<?php echo $row['status']; ?>">
                                    <?php echo ucwords(str_replace('_', ' ', $row['status'])); ?>
                                </span>
                            </td>
                            <td><?php echo format_currency($item_value); ?></td>
                        </tr>
                        <?php endforeach; ?>
                        <tr>
                            <td colspan="7" style="text-align: right;"><strong>Total Value of Items:</strong></td>
                            <td><strong><?php echo format_currency($total_expiry_value); ?></strong></td>
                        </tr>
                    </tbody>
                </table>
            <?php elseif ($report_type == 'activity'): ?>
                <table class="data-table" id="reportTable">
                    <thead>
                        <tr>
                            <th>Date & Time</th>
                            <th>User</th>
                            <th>Action</th>
                            <th>Item Type</th>
                            <th>Details</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($report_data as $row): ?>
                        <tr>
                            <td><?php echo date('M d, Y H:i', strtotime($row['created_at'])); ?></td>
                            <td><?php echo htmlspecialchars($row['full_name']); ?></td>
                            <td><?php echo ucfirst(htmlspecialchars($row['action'])); ?></td>
                            <td><?php echo ucfirst(htmlspecialchars($row['item_type'])); ?></td>
                            <td><?php echo htmlspecialchars($row['details']); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>
<?php elseif ($report_type): ?>
    <div class="alert alert-info">
        <p>No data found for the selected report criteria.</p>
    </div>
<?php else: ?>
    <div class="card-grid">
        <div class="card">
            <div class="card-header">
                <h3>Summary Report</h3>
            </div>
            <div class="card-body">
                <p>Get a comprehensive overview of your inventory system with key metrics, trends, and insights all in one place.</p>
            </div>
            <div class="card-footer">
                <a href="index.php?page=reports&report_type=summary" class="btn btn-primary">Generate Report</a>
            </div>
        </div>
        
        <div class="card">
            <div class="card-header">
                <h3>Inventory Value Report</h3>
            </div>
            <div class="card-body">
                <p>Get a breakdown of your inventory value by category. See where your assets are concentrated and make informed decisions.</p>
            </div>
            <div class="card-footer">
                <a href="index.php?page=reports&report_type=inventory_value" class="btn btn-primary">Generate Report</a>
            </div>
        </div>
        
        <div class="card">
            <div class="card-header">
                <h3>Low Stock Report</h3>
            </div>
            <div class="card-body">
                <p>Identify items that need restocking. Shows current quantities, minimum stock levels, and estimated reorder costs.</p>
            </div>
            <div class="card-footer">
                <a href="index.php?page=reports&report_type=low_stock" class="btn btn-warning">Generate Report</a>
            </div>
        </div>
        
        <div class="card">
            <div class="card-header">
                <h3>Expiry Date Report</h3>
            </div>
            <div class="card-body">
                <p>Track items nearing expiration. Default shows items expiring in next 30 days, or select a custom date range.</p>
            </div>
            <div class="card-footer">
                <a href="index.php?page=reports&report_type=expiry" class="btn btn-danger">Generate Report</a>
            </div>
        </div>
        
        <div class="card">
            <div class="card-header">
                <h3>Activity Log Report</h3>
            </div>
            <div class="card-body">
                <p>Review all system activity. See who made changes to the inventory, when they were made, and what was changed.</p>
            </div>
            <div class="card-footer">
                <a href="index.php?page=reports&report_type=activity" class="btn btn-info">Generate Report</a>
            </div>
        </div>
    </div>
<?php endif; ?>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const reportType = document.getElementById('report_type');
        const categoryFilter = document.querySelectorAll('.category-filter');
        const statusFilter = document.querySelectorAll('.status-filter');
        const dateFilter = document.querySelectorAll('.date-filter');
        
        reportType.addEventListener('change', function() {
            // Hide all filters first
            categoryFilter.forEach(filter => filter.style.display = 'none');
            statusFilter.forEach(filter => filter.style.display = 'none');
            dateFilter.forEach(filter => filter.style.display = 'none');
            
            // Show relevant filters based on report type
            switch(this.value) {
                case 'inventory_value':
                    categoryFilter.forEach(filter => filter.style.display = '');
                    statusFilter.forEach(filter => filter.style.display = '');
                    break;
                case 'low_stock':
                    categoryFilter.forEach(filter => filter.style.display = '');
                    break;
                case 'expiry':
                case 'activity':
                case 'summary':
                    dateFilter.forEach(filter => filter.style.display = '');
                    break;
            }
        });
    });
</script>