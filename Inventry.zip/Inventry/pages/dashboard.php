<?php
// Update inventory status
update_inventory_status();

// Get dashboard counts
$counts = get_dashboard_counts();

// Get recent activities
$activities = get_recent_activities(5);

// Get low stock items
$low_stock_items = get_inventory(null, null, 'low_stock', 5);

// Prepare chart data
$category_data = [
    'labels' => ['Livestock', 'Equipment', 'Crops', 'Supplies'],
    'data' => [
        $counts['livestock'],
        $counts['equipment'],
        $counts['crops'],
        $counts['supplies']
    ]
];

$status_data = [
    'labels' => ['Available', 'Low Stock', 'Out of Stock', 'Expired'],
    'data' => [
        $counts['total_inventory'] - $counts['low_stock'] - $counts['out_of_stock'] - $counts['expired'],
        $counts['low_stock'],
        $counts['out_of_stock'],
        $counts['expired']
    ]
];

// Create dummy trend data for demonstration
$trend_labels = [];
$trend_data = [];
$today = new DateTime();

for ($i = 6; $i >= 0; $i--) {
    $date = clone $today;
    $date->modify("-$i days");
    $trend_labels[] = $date->format('M d');
    
    // Generate some random data that trends upward
    $base_value = $counts['total_value'] * 0.9;
    $random_factor = rand(95, 105) / 100;
    $day_factor = (7 - $i) / 7 * 0.1;
    $trend_data[] = round($base_value * (1 + $day_factor) * $random_factor);
}

$trend_data = [
    'labels' => $trend_labels,
    'data' => $trend_data
];
?>

<h1>Dashboard</h1>

<!-- Dashboard Stats -->
<div class="dashboard-stats">
    <div class="stat-card">
        <div class="stat-icon">
            <i class="fas fa-boxes"></i>
        </div>
        <div class="stat-content">
            <h3>Total Inventory</h3>
            <p><?php echo $counts['total_inventory']; ?> items</p>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon info">
            <i class="fas fa-dollar-sign"></i>
        </div>
        <div class="stat-content">
            <h3>Total Value</h3>
            <p><?php echo format_currency($counts['total_value']); ?></p>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon warning">
            <i class="fas fa-exclamation-triangle"></i>
        </div>
        <div class="stat-content">
            <h3>Low Stock Items</h3>
            <p><?php echo $counts['low_stock']; ?> items</p>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon danger">
            <i class="fas fa-times-circle"></i>
        </div>
        <div class="stat-content">
            <h3>Out of Stock</h3>
            <p><?php echo $counts['out_of_stock']; ?> items</p>
        </div>
    </div>
</div>

<!-- Low Stock Alert -->
<?php if(count($low_stock_items) > 0): ?>
<div class="low-stock-alert">
    <h3><i class="fas fa-exclamation-triangle"></i> Low Stock Alert</h3>
    <p>The following items are running low and need to be restocked:</p>
    <ul>
        <?php foreach($low_stock_items as $item): ?>
        <li>
            <strong><?php echo htmlspecialchars($item['name']); ?></strong> - 
            <?php echo $item['quantity'] . ' ' . htmlspecialchars($item['unit']); ?> remaining
            (Min: <?php echo $item['min_stock_level']; ?>)
        </li>
        <?php endforeach; ?>
    </ul>
    <a href="index.php?page=inventory&status=low_stock" class="btn btn-warning btn-small">View All Low Stock Items</a>
</div>
<?php endif; ?>

<!-- Dashboard Charts -->
<div class="dashboard-charts">
    <div class="chart-card">
        <h2>Inventory Value Trend (Last 7 Days)</h2>
        <canvas id="trendChart"></canvas>
        <script id="trendData" type="application/json"><?php echo json_encode($trend_data); ?></script>
    </div>
    
    <div class="chart-card">
        <h2>Inventory by Category</h2>
        <canvas id="inventoryChart"></canvas>
        <script id="inventoryData" type="application/json"><?php echo json_encode($category_data); ?></script>
    </div>
</div>

<div class="dashboard-charts">
    <div class="chart-card">
        <h2>Recent Activity</h2>
        <div class="activity-list">
            <?php if(count($activities) > 0): ?>
                <?php foreach($activities as $activity): ?>
                <div class="activity-item">
                    <p>
                        <strong><?php echo htmlspecialchars($activity['full_name']); ?></strong> 
                        <?php echo htmlspecialchars($activity['action']); ?>ed 
                        <?php echo htmlspecialchars($activity['item_type']); ?>
                        <?php if($activity['details']): ?>
                            - <?php echo htmlspecialchars($activity['details']); ?>
                        <?php endif; ?>
                    </p>
                    <div class="activity-meta">
                        <?php echo date('M d, Y H:i', strtotime($activity['created_at'])); ?>
                    </div>
                </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>No recent activity found.</p>
            <?php endif; ?>
        </div>
    </div>
    
    <div class="chart-card">
        <h2>Inventory Status</h2>
        <canvas id="statusChart"></canvas>
        <script id="statusData" type="application/json"><?php echo json_encode($status_data); ?></script>
    </div>
</div>