<?php
// Check if we need to process any actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Add new inventory item
    if (isset($_POST['add_inventory'])) {
        $name = sanitize_input($_POST['name']);
        $category_id = (int)$_POST['category_id'];
        $quantity = (int)$_POST['quantity'];
        $unit = sanitize_input($_POST['unit']);
        $price = (float)$_POST['price'];
        $purchase_date = !empty($_POST['purchase_date']) ? $_POST['purchase_date'] : null;
        $expiry_date = !empty($_POST['expiry_date']) ? $_POST['expiry_date'] : null;
        $min_stock_level = (int)$_POST['min_stock_level'];
        $location = sanitize_input($_POST['location']);
        $description = sanitize_input($_POST['description']);
        
        // Determine status based on quantity and expiry date
        $status = 'available';
        if ($quantity <= 0) {
            $status = 'out_of_stock';
        } elseif ($quantity <= $min_stock_level) {
            $status = 'low_stock';
        }
        
        if ($expiry_date && strtotime($expiry_date) < strtotime('today')) {
            $status = 'expired';
        }
        
        // Handle image upload if provided
        $image = '';
        if (isset($_FILES['image']) && $_FILES['image']['error'] === 0) {
            $upload_dir = 'uploads/';
            if (!file_exists($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }
            
            $file_name = time() . '_' . basename($_FILES['image']['name']);
            $target_file = $upload_dir . $file_name;
            
            if (move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
                $image = $target_file;
            }
        }
        
        // Insert into database
        $stmt = $conn->prepare("INSERT INTO inventory (name, category_id, quantity, unit, price, purchase_date, expiry_date, min_stock_level, location, status, description, image) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("siisdssissss", $name, $category_id, $quantity, $unit, $price, $purchase_date, $expiry_date, $min_stock_level, $location, $status, $description, $image);
        
        if ($stmt->execute()) {
            $item_id = $conn->insert_id;
            
            // Log activity
            log_activity($_SESSION['user_id'], 'add', $item_id, 'inventory', "Added inventory item: $name");
            
            // Set success message
            $_SESSION['success_message'] = "Inventory item added successfully!";
        } else {
            $_SESSION['error_message'] = "Error adding inventory item: " . $conn->error;
        }
        
        // Redirect to prevent form resubmission
        header("Location: index.php?page=inventory");
        exit();
    }
    
    // Update inventory item
    if (isset($_POST['update_inventory'])) {
        $item_id = (int)$_POST['item_id'];
        $name = sanitize_input($_POST['name']);
        $category_id = (int)$_POST['category_id'];
        $quantity = (int)$_POST['quantity'];
        $unit = sanitize_input($_POST['unit']);
        $price = (float)$_POST['price'];
        $purchase_date = !empty($_POST['purchase_date']) ? $_POST['purchase_date'] : null;
        $expiry_date = !empty($_POST['expiry_date']) ? $_POST['expiry_date'] : null;
        $min_stock_level = (int)$_POST['min_stock_level'];
        $location = sanitize_input($_POST['location']);
        $description = sanitize_input($_POST['description']);
        
        // Get current item details for comparison
        $current_item = get_inventory_item($item_id);
        
        // Handle image upload if provided
        $image = $current_item['image'];
        if (isset($_FILES['image']) && $_FILES['image']['error'] === 0) {
            $upload_dir = 'uploads/';
            if (!file_exists($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }
            
            $file_name = time() . '_' . basename($_FILES['image']['name']);
            $target_file = $upload_dir . $file_name;
            
            if (move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
                // Delete old image if exists
                if (!empty($current_item['image']) && file_exists($current_item['image'])) {
                    unlink($current_item['image']);
                }
                $image = $target_file;
            }
        }
        
        // Begin transaction to ensure data consistency
        $conn->begin_transaction();
        
        try {
            // Update inventory
            $stmt = $conn->prepare("UPDATE inventory SET name = ?, category_id = ?, quantity = ?, unit = ?, price = ?, purchase_date = ?, expiry_date = ?, min_stock_level = ?, location = ?, description = ?, image = ? WHERE id = ?");
            $stmt->bind_param("siisdssisssi", $name, $category_id, $quantity, $unit, $price, $purchase_date, $expiry_date, $min_stock_level, $location, $description, $image, $item_id);
            if (!$stmt->execute()) {
                throw new Exception("Error updating inventory item: " . $conn->error);
            }
            
            // Update status based on quantity and expiry date
            $status = 'available';
            if ($quantity <= 0) {
                $status = 'out_of_stock';
            } elseif ($quantity <= $min_stock_level) {
                $status = 'low_stock';
            }
            if ($expiry_date && strtotime($expiry_date) < strtotime('today')) {
                $status = 'expired';
            }
            
            $stmt_status = $conn->prepare("UPDATE inventory SET status = ? WHERE id = ?");
            $stmt_status->bind_param("si", $status, $item_id);
            if (!$stmt_status->execute()) {
                throw new Exception("Error updating inventory status: " . $conn->error);
            }
            
            // Insert transaction record
            $transaction_type = 'update';
            $stmt_transaction = $conn->prepare("INSERT INTO inventory_transactions (inventory_id, user_id, transaction_type, quantity, unit, notes) VALUES (?, ?, ?, ?, ?, ?)");
            $notes = "Updated item: $name";
            $stmt_transaction->bind_param("iisiss", $item_id, $_SESSION['user_id'], $transaction_type, $quantity, $unit, $notes);
            if (!$stmt_transaction->execute()) {
                throw new Exception("Error recording transaction: " . $conn->error);
            }
            
            // Log activity
            log_activity($_SESSION['user_id'], 'update', $item_id, 'inventory', "Updated inventory item: $name");
            
            // Commit transaction
            $conn->commit();
            
            // Set success message
            $_SESSION['success_message'] = "Inventory item updated successfully!";
        } catch (Exception $e) {
            // Rollback transaction on error
            $conn->rollback();
            $_SESSION['error_message'] = $e->getMessage();
        }
        
        // Redirect to prevent form resubmission
        header("Location: index.php?page=inventory");
        exit();
    }
    
    // Delete inventory item
    if (isset($_POST['delete_inventory'])) {
        $item_id = (int)$_POST['item_id'];
        
        // Get item details for logging and image deletion
        $item = get_inventory_item($item_id);
        
        if ($item) {
            // Delete item from database
            $stmt = $conn->prepare("DELETE FROM inventory WHERE id = ?");
            $stmt->bind_param("i", $item_id);
            
            if ($stmt->execute()) {
                // Delete image if exists
                if (!empty($item['image']) && file_exists($item['image'])) {
                    unlink($item['image']);
                }
                
                // Log activity
                log_activity($_SESSION['user_id'], 'delete', $item_id, 'inventory', "Deleted inventory item: {$item['name']}");
                
                // Set success message
                $_SESSION['success_message'] = "Inventory item deleted successfully!";
            } else {
                $_SESSION['error_message'] = "Error deleting inventory item: " . $conn->error;
            }
        } else {
            $_SESSION['error_message'] = "Inventory item not found.";
        }
        
        // Redirect to prevent form resubmission
        header("Location: index.php?page=inventory");
        exit();
    }
    
    // Retrieve inventory item
    if (isset($_POST['retrieve_inventory'])) {
        $item_id = (int)$_POST['item_id'];
        $retrieve_qty = (int)$_POST['retrieve_qty'];
        $notes = isset($_POST['retrieve_notes']) ? sanitize_input($_POST['retrieve_notes']) : null;
        
        // Get current item details
        $item = get_inventory_item($item_id);
        
        if ($item) {
            if ($retrieve_qty > 0 && $retrieve_qty <= $item['quantity']) {
                $new_quantity = $item['quantity'] - $retrieve_qty;
                
                // Begin transaction to ensure data consistency
                $conn->begin_transaction();
                
                try {
                    // Update inventory quantity
                    $stmt = $conn->prepare("UPDATE inventory SET quantity = ? WHERE id = ?");
                    $stmt->bind_param("ii", $new_quantity, $item_id);
                    if (!$stmt->execute()) {
                        throw new Exception("Error updating inventory quantity: " . $conn->error);
                    }
                    
                    // Update status based on new quantity
                    $status = 'available';
                    if ($new_quantity <= 0) {
                        $status = 'out_of_stock';
                    } elseif ($new_quantity <= $item['min_stock_level']) {
                        $status = 'low_stock';
                    }
                    if ($item['expiry_date'] && strtotime($item['expiry_date']) < strtotime('today')) {
                        $status = 'expired';
                    }
                    
                    $stmt_status = $conn->prepare("UPDATE inventory SET status = ? WHERE id = ?");
                    $stmt_status->bind_param("si", $status, $item_id);
                    if (!$stmt_status->execute()) {
                        throw new Exception("Error updating inventory status: " . $conn->error);
                    }
                    
                    // Insert transaction record
                    $transaction_type = 'retrieve';
                    $stmt_transaction = $conn->prepare("INSERT INTO inventory_transactions (inventory_id, user_id, transaction_type, quantity, unit, notes) VALUES (?, ?, ?, ?, ?, ?)");
                    $stmt_transaction->bind_param("iisiss", $item_id, $_SESSION['user_id'], $transaction_type, $retrieve_qty, $item['unit'], $notes);
                    if (!$stmt_transaction->execute()) {
                        throw new Exception("Error recording transaction: " . $conn->error);
                    }
                    
                    // Log activity with truncated notes
                    $log_notes = $notes ? " (Notes: " . substr($notes, 0, 100) . (strlen($notes) > 100 ? "..." : "") . ")" : "";
                    log_activity($_SESSION['user_id'], 'retrieve', $item_id, 'inventory', "Retrieved $retrieve_qty {$item['unit']} of {$item['name']}" . $log_notes);
                    
                    // Commit transaction
                    $conn->commit();
                    
                    // Set success message
                    $_SESSION['success_message'] = "Successfully retrieved $retrieve_qty {$item['unit']} of {$item['name']}.";
                } catch (Exception $e) {
                    // Rollback transaction on error
                    $conn->rollback();
                    $_SESSION['error_message'] = $e->getMessage();
                }
            } else {
                $_SESSION['error_message'] = "Invalid retrieval quantity or insufficient stock.";
            }
        } else {
            $_SESSION['error_message'] = "Inventory item not found.";
        }
        
        // Redirect to prevent form resubmission
        header("Location: index.php?page=inventory");
        exit();
    }
}

// Function to get transaction history
function get_transaction_history($inventory_id = null) {
    global $conn;
    $query = "SELECT it.*, i.name AS item_name, u.username 
              FROM inventory_transactions it 
              JOIN inventory i ON it.inventory_id = i.id 
              JOIN users u ON it.user_id = u.id";
    if ($inventory_id) {
        $query .= " WHERE it.inventory_id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $inventory_id);
    } else {
        $stmt = $conn->prepare($query);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_all(MYSQLI_ASSOC);
}

// Get filters from GET parameters
$category_id = isset($_GET['category_id']) ? (int)$_GET['category_id'] : null;
$search = isset($_GET['search']) ? sanitize_input($_GET['search']) : null;
$status = isset($_GET['status']) ? sanitize_input($_GET['status']) : null;

// Pagination
$page = isset($_GET['p']) ? (int)$_GET['p'] : 1;
$items_per_page = 10;
$offset = ($page - 1) * $items_per_page;

// Get total items count
$total_items = count_inventory($category_id, $search, $status);
$total_pages = ceil($total_items / $items_per_page);

// Get inventory items with pagination
$inventory_items = get_inventory($category_id, $search, $status, $items_per_page, $offset);

// Get all categories for filter and form
$categories = get_categories();
?>

<h1>Inventory Management</h1>

<!-- Success and Error Messages -->
<?php if (isset($_SESSION['success_message'])): ?>
    <div class="alert alert-success">
        <?php 
            echo $_SESSION['success_message']; 
            unset($_SESSION['success_message']);
        ?>
    </div>
<?php endif; ?>

<?php if (isset($_SESSION['error_message'])): ?>
    <div class="alert alert-danger">
        <?php 
            echo $_SESSION['error_message']; 
            unset($_SESSION['error_message']);
        ?>
    </div>
<?php endif; ?>

<!-- Filter Form -->
<div class="filter-container">
    <form action="index.php" method="GET" class="filter-form">
        <input type="hidden" name="page" value="inventory">
        
        <div class="filter-group">
            <label for="category">Category</label>
            <select name="category_id" id="category" class="filter-input">
                <option value="">All Categories</option>
                <?php foreach ($categories as $category): ?>
                <option value="<?php echo $category['id']; ?>" <?php echo ($category_id == $category['id']) ? 'selected' : ''; ?>>
                    <?php echo htmlspecialchars($category['name']); ?> (<?php echo htmlspecialchars($category['type']); ?>)
                </option>
                <?php endforeach; ?>
            </select>
        </div>
        
        <div class="filter-group">
            <label for="status">Status</label>
            <select name="status" id="status" class="filter-input">
                <option value="">All Status</option>
                <option value="available" <?php echo ($status == 'available') ? 'selected' : ''; ?>>Available</option>
                <option value="low_stock" <?php echo ($status == 'low_stock') ? 'selected' : ''; ?>>Low Stock</option>
                <option value="out_of_stock" <?php echo ($status == 'out_of_stock') ? 'selected' : ''; ?>>Out of Stock</option>
                <option value="expired" <?php echo ($status == 'expired') ? 'selected' : ''; ?>>Expired</option>
            </select>
        </div>
        
        <div class="filter-group">
            <label for="search">Search</label>
            <input type="text" name="search" id="search" class="filter-input" placeholder="Search..." value="<?php echo htmlspecialchars($search ?? ''); ?>">
        </div>
        
        <div class="filter-buttons">
            <button type="submit" class="btn btn-primary">Filter</button>
            <a href="index.php?page=inventory" class="btn btn-outline">Reset</a>
        </div>
    </form>
</div>

<!-- Inventory Table -->
<div class="page-header">
    <h2>Inventory Items</h2>
    <button class="btn btn-primary" data-modal-target="addItemModal">
        <i class="fas fa-plus"></i> Add New Item
    </button>
</div>

<div class="data-container">
    <?php if (count($inventory_items) > 0): ?>
        <table class="data-table" id="inventoryTable">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Category</th>
                    <th>Quantity</th>
                    <th>Price</th>
                    <th>Value</th>
                    <th>Location</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($inventory_items as $index => $item): ?>
                <tr>
                    <td><?php echo $offset + $index + 1; ?></td>
                    <td><?php echo htmlspecialchars($item['name']); ?></td>
                    <td><?php echo htmlspecialchars($item['category_name']); ?></td>
                    <td><?php echo $item['quantity'] . ' ' . htmlspecialchars($item['unit']); ?></td>
                    <td><?php echo format_currency($item['price']); ?></td>
                    <td><?php echo format_currency($item['quantity'] * $item['price']); ?></td>
                    <td><?php echo htmlspecialchars($item['location']); ?></td>
                    <td>
                        <span class="item-status status-<?php echo $item['status']; ?>">
                            <?php 
                                $status_text = str_replace('_', ' ', $item['status']);
                                echo ucwords($status_text);
                            ?>
                        </span>
                    </td>
                    <td>
                        <div class="table-actions">
                            <button class="btn btn-small btn-info" data-modal-target="viewItemModal<?php echo $item['id']; ?>">
                                <i class="fas fa-eye"></i>
                            </button>
                            <button class="btn btn-small btn-primary" data-modal-target="editItemModal<?php echo $item['id']; ?>">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="btn btn-small btn-warning" data-modal-target="retrieveItemModal" onclick="setRetrieveItem(<?php echo (int)$item['id']; ?>, '<?php echo htmlspecialchars(addslashes($item['name']), ENT_QUOTES, 'UTF-8'); ?>', '<?php echo htmlspecialchars(addslashes($item['category_name']), ENT_QUOTES, 'UTF-8'); ?>', <?php echo (int)$item['quantity']; ?>, '<?php echo htmlspecialchars(addslashes($item['unit']), ENT_QUOTES, 'UTF-8'); ?>', '<?php echo htmlspecialchars(addslashes($item['location'] ?: 'Not specified'), ENT_QUOTES, 'UTF-8'); ?>')">
                                <i class="fas fa-arrow-down"></i>
                            </button>
                            <button class="btn btn-small btn-danger" onclick="confirmDelete(<?php echo (int)$item['id']; ?>, 'inventory')">
                                <i class="fas fa-trash"></i>
                            </button>
                            
                            <!-- Hidden delete form -->
                            <form id="delete-inventory-<?php echo $item['id']; ?>" action="index.php?page=inventory" method="POST" style="display: none;">
                                <input type="hidden" name="delete_inventory" value="1">
                                <input type="hidden" name="item_id" value="<?php echo $item['id']; ?>">
                            </form>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        
        <!-- Pagination -->
        <?php if ($total_pages > 1): ?>
        <div class="pagination">
            <?php if ($page > 1): ?>
            <div class="pagination-item">
                <a href="index.php?page=inventory&p=1<?php echo isset($category_id) ? '&category_id='.$category_id : ''; ?><?php echo isset($search) ? '&search='.urlencode($search) : ''; ?><?php echo isset($status) ? '&status='.$status : ''; ?>" class="pagination-link">
                    «
                </a>
            </div>
            <?php endif; ?>
            
            <?php for ($i = max(1, $page - 2); $i <= min($total_pages, $page + 2); $i++): ?>
            <div class="pagination-item">
                <a href="index.php?page=inventory&p=<?php echo $i; ?><?php echo isset($category_id) ? '&category_id='.$category_id : ''; ?><?php echo isset($search) ? '&search='.urlencode($search) : ''; ?><?php echo isset($status) ? '&status='.$status : ''; ?>" class="pagination-link <?php echo ($i == $page) ? 'active' : ''; ?>">
                    <?php echo $i; ?>
                </a>
            </div>
            <?php endfor; ?>
            
            <?php if ($page < $total_pages): ?>
            <div class="pagination-item">
                <a href="index.php?page=inventory&p=<?php echo $total_pages; ?><?php echo isset($category_id) ? '&category_id='.$category_id : ''; ?><?php echo isset($search) ? '&search='.urlencode($search) : ''; ?><?php echo isset($status) ? '&status='.$status : ''; ?>" class="pagination-link">
                    »
                </a>
            </div>
            <?php endif; ?>
        </div>
        <?php endif; ?>
        
        <div style="margin-top: 15px;">
            <button class="btn btn-outline" onclick="exportToCSV('inventoryTable', 'inventory_export.csv')">
                <i class="fas fa-download"></i> Export to CSV
            </button>
        </div>
    <?php else: ?>
        <p>No inventory items found.</p>
    <?php endif; ?>
</div>

<!-- Add Item Modal -->
<div class="modal-overlay" id="addItemModal">
    <div class="modal">
        <div class="modal-header">
            <h3 class="modal-title">Add New Inventory Item</h3>
            <button class="modal-close" data-modal-close>×</button>
        </div>
        <div class="modal-body">
            <form action="index.php?page=inventory" method="POST" enctype="multipart/form-data" data-validate>
                <input type="hidden" name="add_inventory" value="1">
                <div class="form-row">
                    <div class="form-group">
                        <label for="name">Item Name</label>
                        <input type="text" id="name" name="name" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="category_id">Category</label>
                        <select id="category_id" name="category_id" class="form-control" required>
                            <option value="">Select Category</option>
                            <?php foreach ($categories as $category): ?>
                            <option value="<?php echo htmlspecialchars($category['id']); ?>">
                                <?php echo htmlspecialchars($category['name']); ?> (<?php echo htmlspecialchars($category['type']); ?>)
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="quantity">Quantity</label>
                        <input type="number" id="quantity" name="quantity" class="form-control" min="0" required>
                    </div>
                    <div class="form-group">
                        <label for="unit">Unit</label>
                        <input type="text" id="unit" name="unit" class="form-control" placeholder="e.g., g, kg, pcs, liters" required>
                    </div>
                    <div class="form-group">
                        <label for="price">Price Per Unit</label>
                        <input type="number" id="price" name="price" class="form-control" min="0" step="0.01" required>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="purchase_date">Purchase Date</label>
                        <input type="date" id="purchase_date" name="purchase_date" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="expiry_date">Expiry Date</label>
                        <input type="date" id="expiry_date" name="expiry_date" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="min_stock_level">Minimum Stock Level</label>
                        <input type="number" id="min_stock_level" name="min_stock_level" class="form-control" min="0" value="0" required>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="location">Storage Location</label>
                        <input type="text" id="location" name="location" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="image">Item Image</label>
                        <input type="file" id="image" name="image" class="form-control" accept="image/*">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group" style="width: 100%;">
                        <label for="description">Description</label>
                        <textarea id="description" name="description" class="form-control"></textarea>
                    </div>
                </div>
                <div class="form-actions">
                    <button type="button" class="btn btn-outline" data-modal-close>Cancel</button>
                    <button type="submit" class="btn btn-primary">Add Item</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Retrieve Item Modal -->
<div class="modal-overlay" id="retrieveItemModal">
    <div class="modal">
        <div class="modal-header">
            <h3 class="modal-title">Retrieve Inventory Item</h3>
            <button class="modal-close" data-modal-close>×</button>
        </div>
        <div class="modal-body">
            <form action="index.php?page=inventory" method="POST" data-validate>
                <input type="hidden" name="retrieve_inventory" value="1">
                <input type="hidden" name="item_id" id="retrieve_item_id">
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="retrieve_name">Item Name</label>
                        <input type="text" id="retrieve_name" class="form-control" readonly>
                    </div>
                    <div class="form-group">
                        <label for="retrieve_category">Category</label>
                        <input type="text" id="retrieve_category" class="form-control" readonly>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="retrieve_quantity">Current Quantity</label>
                        <input type="text" id="retrieve_quantity" class="form-control" readonly>
                    </div>
                    <div class="form-group">
                        <label for="retrieve_location">Storage Location</label>
                        <input type="text" id="retrieve_location" class="form-control" readonly>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="retrieve_qty">Quantity to Retrieve</label>
                        <input type="number" id="retrieve_qty" name="retrieve_qty" class="form-control" min="1" required>
                    </div>
                    <div class="form-group">
                        <label for="retrieve_notes">Notes (Optional)</label>
                        <textarea id="retrieve_notes" name="retrieve_notes" class="form-control" placeholder="Add any notes about this retrieval"></textarea>
                    </div>
                </div>

                <div class="form-actions">
                    <button type="button" class="btn btn-outline" data-modal-close>Cancel</button>
                    <button type="submit" class="btn btn-warning">Retrieve</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- View and Edit Item Modals -->
<?php foreach ($inventory_items as $item): ?>
    <!-- View Item Modal -->
    <div class="modal-overlay" id="viewItemModal<?php echo $item['id']; ?>">
        <div class="modal">
            <div class="modal-header">
                <h3 class="modal-title">View Inventory Item</h3>
                <button class="modal-close" data-modal-close>×</button>
            </div>
            <div class="modal-body">
                <div class="form-row">
                    <div class="form-group">
                        <label>Item Name</label>
                        <p class="form-control"><?php echo htmlspecialchars($item['name']); ?></p>
                    </div>
                    <div class="form-group">
                        <label>Category</label>
                        <p class="form-control"><?php echo htmlspecialchars($item['category_name']); ?> (<?php echo htmlspecialchars($item['category_type']); ?>)</p>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Quantity</label>
                        <p class="form-control"><?php echo $item['quantity'] . ' ' . htmlspecialchars($item['unit']); ?></p>
                    </div>
                    <div class="form-group">
                        <label>Price Per Unit</label>
                        <p class="form-control"><?php echo format_currency($item['price']); ?></p>
                    </div>
                    <div class="form-group">
                        <label>Total Value</label>
                        <p class="form-control"><?php echo format_currency($item['quantity'] * $item['price']); ?></p>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Purchase Date</label>
                        <p class="form-control"><?php echo $item['purchase_date'] ? date('M d, Y', strtotime($item['purchase_date'])) : 'Not specified'; ?></p>
                    </div>
                    <div class="form-group">
                        <label>Expiry Date</label>
                        <p class="form-control"><?php echo $item['expiry_date'] ? date('M d, Y', strtotime($item['expiry_date'])) : 'Not applicable'; ?></p>
                    </div>
                    <div class="form-group">
                        <label>Minimum Stock Level</label>
                        <p class="form-control"><?php echo $item['min_stock_level']; ?></p>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Storage Location</label>
                        <p class="form-control"><?php echo htmlspecialchars($item['location'] ?: 'Not specified'); ?></p>
                    </div>
                    <div class="form-group">
                        <label>Status</label>
                        <p class="form-control">
                            <span class="item-status status-<?php echo $item['status']; ?>">
                                <?php 
                                    $status_text = str_replace('_', ' ', $item['status']);
                                    echo ucwords($status_text);
                                ?>
                            </span>
                        </p>
                    </div>
                </div>
                <?php if (!empty($item['image']) && file_exists($item['image'])): ?>
                <div class="form-row">
                    <div class="form-group" style="width: 100%;">
                        <label>Item Image</label>
                        <div>
                            <img src="<?php echo htmlspecialchars($item['image']); ?>" alt="<?php echo htmlspecialchars($item['name']); ?>" style="max-width: 100%; max-height: 200px;">
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                <div class="form-row">
                    <div class="form-group" style="width: 100%;">
                        <label>Description</label>
                        <p class="form-control" style="min-height: 60px;"><?php echo nl2br(htmlspecialchars($item['description'] ?: 'No description provided.')); ?></p>
                    </div>
                </div>
                <!-- Transaction History -->
                <div class="form-row">
                    <div class="form-group" style="width: 100%;">
                        <label>Transaction History</label>
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>User</th>
                                    <th>Type</th>
                                    <th>Quantity</th>
                                    <th>Notes</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                    $transactions = get_transaction_history($item['id']);
                                    if (count($transactions) > 0):
                                        foreach ($transactions as $transaction):
                                ?>
                                <tr>
                                    <td><?php echo date('M d, Y H:i:s A', strtotime($transaction['created_at'])); ?></td>
                                    <td><?php echo htmlspecialchars($transaction['username']); ?></td>
                                    <td><?php echo ucwords($transaction['transaction_type']); ?></td>
                                    <td><?php echo $transaction['quantity'] . ' ' . htmlspecialchars($transaction['unit']); ?></td>
                                    <td><?php echo htmlspecialchars($transaction['notes'] ?: 'No notes'); ?></td>
                                </tr>
                                <?php 
                                        endforeach;
                                    else:
                                ?>
                                <tr>
                                    <td colspan="5">No transactions recorded.</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="form-actions">
                    <button type="button" class="btn btn-outline" data-modal-close>Close</button>
                    <button type="button" class="btn btn-primary" data-modal-close data-modal-target="editItemModal<?php echo $item['id']; ?>">Edit</button>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Edit Item Modal -->
    <div class="modal-overlay" id="editItemModal<?php echo $item['id']; ?>">
        <div class="modal">
            <div class="modal-header">
                <h3 class="modal-title">Edit Inventory Item</h3>
                <button class="modal-close" data-modal-close>×</button>
            </div>
            <div class="modal-body">
                <form action="index.php?page=inventory" method="POST" enctype="multipart/form-data" data-validate>
                    <input type="hidden" name="update_inventory" value="1">
                    <input type="hidden" name="item_id" value="<?php echo $item['id']; ?>">
                    <div class="form-row">
                        <div class="form-group">
                            <label for="edit_name_<?php echo $item['id']; ?>">Item Name</label>
                            <input type="text" id="edit_name_<?php echo $item['id']; ?>" name="name" class="form-control" value="<?php echo htmlspecialchars($item['name']); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="edit_category_id_<?php echo $item['id']; ?>">Category</label>
                            <select id="edit_category_id_<?php echo $item['id']; ?>" name="category_id" class="form-control" required>
                                <?php foreach ($categories as $category): ?>
                                <option value="<?php echo $category['id']; ?>" <?php echo ($category['id'] == $item['category_id']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($category['name']); ?> (<?php echo htmlspecialchars($category['type']); ?>)
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="edit_quantity_<?php echo $item['id']; ?>">Quantity</label>
                            <input type="number" id="edit_quantity_<?php echo $item['id']; ?>" name="quantity" class="form-control" min="0" value="<?php echo $item['quantity']; ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="edit_unit_<?php echo $item['id']; ?>">Unit</label>
                            <input type="text" id="edit_unit_<?php echo $item['id']; ?>" name="unit" class="form-control" value="<?php echo htmlspecialchars($item['unit']); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="edit_price_<?php echo $item['id']; ?>">Price Per Unit</label>
                            <input type="number" id="edit_price_<?php echo $item['id']; ?>" name="price" class="form-control" min="0" step="0.01" value="<?php echo $item['price']; ?>" required>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="edit_purchase_date_<?php echo $item['id']; ?>">Purchase Date</label>
                            <input type="date" id="edit_purchase_date_<?php echo $item['id']; ?>" name="purchase_date" class="form-control" value="<?php echo $item['purchase_date']; ?>">
                        </div>
                        <div class="form-group">
                            <label for="edit_expiry_date_<?php echo $item['id']; ?>">Expiry Date</label>
                            <input type="date" id="edit_expiry_date_<?php echo $item['id']; ?>" name="expiry_date" class="form-control" value="<?php echo $item['expiry_date']; ?>">
                        </div>
                        <div class="form-group">
                            <label for="edit_min_stock_level_<?php echo $item['id']; ?>">Minimum Stock Level</label>
                            <input type="number" id="edit_min_stock_level_<?php echo $item['id']; ?>" name="min_stock_level" class="form-control" min="0" value="<?php echo $item['min_stock_level']; ?>" required>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="edit_location_<?php echo $item['id']; ?>">Storage Location</label>
                            <input type="text" id="edit_location_<?php echo $item['id']; ?>" name="location" class="form-control" value="<?php echo htmlspecialchars($item['location']); ?>">
                        </div>
                        <div class="form-group">
                            <label for="edit_image_<?php echo $item['id']; ?>">Item Image</label>
                            <input type="file" id="edit_image_<?php echo $item['id']; ?>" name="image" class="form-control" accept="image/*">
                            <?php if (!empty($item['image']) && file_exists($item['image'])): ?>
                                <small>Current image: <?php echo htmlspecialchars(basename($item['image'])); ?></small>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group" style="width: 100%;">
                            <label for="edit_description_<?php echo $item['id']; ?>">Description</label>
                            <textarea id="edit_description_<?php echo $item['id']; ?>" name="description" class="form-control"><?php echo htmlspecialchars($item['description']); ?></textarea>
                        </div>
                    </div>
                    <div class="form-actions">
                        <button type="button" class="btn btn-outline" data-modal-close>Cancel</button>
                        <button type="submit" class="btn btn-primary">Update Item</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php endforeach; ?>

<script>
function setRetrieveItem(itemId, name, category, quantity, unit, location) {
    document.getElementById('retrieve_item_id').value = itemId;
    document.getElementById('retrieve_name').value = name;
    document.getElementById('retrieve_category').value = category;
    document.getElementById('retrieve_quantity').value = quantity + ' ' + unit;
    document.getElementById('retrieve_location').value = location;
    document.getElementById('retrieve_qty').setAttribute('max', quantity);
}

document.querySelector('#retrieveItemModal form').addEventListener('submit', function(e) {
    const qtyInput = document.getElementById('retrieve_qty');
    const maxQty = parseInt(qtyInput.getAttribute('max'));
    const enteredQty = parseInt(qtyInput.value);
    if (enteredQty > maxQty) {
        e.preventDefault();
        alert('Quantity to retrieve cannot exceed available quantity (' + maxQty + ' ' + unit + ').');
    }
});

function confirmDelete(itemId, type) {
    if (confirm('Are you sure you want to delete this inventory item?')) {
        document.getElementById('delete-inventory-' + itemId).submit();
    }
}
</script>