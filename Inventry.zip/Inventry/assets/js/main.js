document.addEventListener('DOMContentLoaded', function() {
    // Sidebar toggle
    const sidebarToggle = document.getElementById('sidebar-toggle');
    if (sidebarToggle) {
        sidebarToggle.addEventListener('click', function() {
            document.querySelector('.sidebar').classList.toggle('active');
        });
    }
    
    // Modal functionality
    const modalTriggers = document.querySelectorAll('[data-modal-target]');
    const modalCloseButtons = document.querySelectorAll('[data-modal-close]');
    
    modalTriggers.forEach(trigger => {
        trigger.addEventListener('click', () => {
            const modalId = trigger.getAttribute('data-modal-target');
            const modal = document.getElementById(modalId);
            if (modal) {
                modal.classList.add('active');
            }
        });
    });
    
    modalCloseButtons.forEach(button => {
        button.addEventListener('click', () => {
            const modal = button.closest('.modal-overlay');
            if (modal) {
                modal.classList.remove('active');
            }
        });
    });
    
    // Close modal when clicking on overlay
    document.querySelectorAll('.modal-overlay').forEach(overlay => {
        overlay.addEventListener('click', (e) => {
            if (e.target === overlay) {
                overlay.classList.remove('active');
            }
        });
    });
    
    // Tabs functionality
    const tabItems = document.querySelectorAll('.tab-item');
    const tabContents = document.querySelectorAll('.tab-content-item');
    
    tabItems.forEach(tab => {
        tab.addEventListener('click', () => {
            const tabId = tab.getAttribute('data-tab');
            
            // Remove active class from all tabs and contents
            tabItems.forEach(item => item.classList.remove('active'));
            tabContents.forEach(content => content.classList.remove('active'));
            
            // Add active class to clicked tab and its content
            tab.classList.add('active');
            document.getElementById(tabId).classList.add('active');
        });
    });
    
    // Form validation
    const forms = document.querySelectorAll('form[data-validate]');
    
    forms.forEach(form => {
        form.addEventListener('submit', (e) => {
            let isValid = true;
            
            // Check required fields
            const requiredFields = form.querySelectorAll('[required]');
            requiredFields.forEach(field => {
                if (!field.value.trim()) {
                    isValid = false;
                    field.classList.add('is-invalid');
                    
                    // Create or update error message
                    let errorMsg = field.nextElementSibling;
                    if (!errorMsg || !errorMsg.classList.contains('error-message')) {
                        errorMsg = document.createElement('div');
                        errorMsg.classList.add('error-message');
                        errorMsg.style.color = 'red';
                        errorMsg.style.fontSize = '0.8rem';
                        errorMsg.style.marginTop = '4px';
                        field.parentNode.insertBefore(errorMsg, field.nextSibling);
                    }
                    errorMsg.textContent = 'This field is required';
                } else {
                    field.classList.remove('is-invalid');
                    const errorMsg = field.nextElementSibling;
                    if (errorMsg && errorMsg.classList.contains('error-message')) {
                        errorMsg.textContent = '';
                    }
                }
            });
            
            if (!isValid) {
                e.preventDefault();
            }
        });
    });
    
    // Initialize tooltips
    const tooltips = document.querySelectorAll('[data-tooltip]');
    tooltips.forEach(tooltip => {
        tooltip.addEventListener('mouseenter', () => {
            const tooltipText = tooltip.getAttribute('data-tooltip');
            const tooltipEl = document.createElement('div');
            tooltipEl.classList.add('tooltip');
            tooltipEl.textContent = tooltipText;
            
            // Position the tooltip
            tooltip.style.position = 'relative';
            tooltip.appendChild(tooltipEl);
            
            setTimeout(() => {
                tooltipEl.style.opacity = '1';
                tooltipEl.style.visibility = 'visible';
            }, 10);
        });
        
        tooltip.addEventListener('mouseleave', () => {
            const tooltipEl = tooltip.querySelector('.tooltip');
            if (tooltipEl) {
                tooltipEl.style.opacity = '0';
                tooltipEl.style.visibility = 'hidden';
                
                setTimeout(() => {
                    tooltip.removeChild(tooltipEl);
                }, 300);
            }
        });
    });
    
    // Dashboard charts initialization (if on dashboard page)
    if (document.getElementById('inventoryChart')) {
        initDashboardCharts();
    }
    
    // Confirmation dialogs
    document.querySelectorAll('[data-confirm]').forEach(element => {
        element.addEventListener('click', (e) => {
            const message = element.getAttribute('data-confirm') || 'Are you sure you want to continue?';
            if (!confirm(message)) {
                e.preventDefault();
            }
        });
    });
});

// Initialize dashboard charts
function initDashboardCharts() {
    // Inventory by Category Chart
    const inventoryCtx = document.getElementById('inventoryChart').getContext('2d');
    const inventoryData = JSON.parse(document.getElementById('inventoryData').textContent);
    
    new Chart(inventoryCtx, {
        type: 'pie',
        data: {
            labels: inventoryData.labels,
            datasets: [{
                data: inventoryData.data,
                backgroundColor: [
                    '#4CAF50',  // Primary light
                    '#795548',  // Secondary color
                    '#FFC107',  // Accent color
                    '#2196F3',  // Blue
                    '#9C27B0',  // Purple
                    '#FF5722',  // Deep Orange
                    '#607D8B'   // Blue Grey
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'right',
                }
            }
        }
    });
    
    // Inventory Status Chart
    const statusCtx = document.getElementById('statusChart').getContext('2d');
    const statusData = JSON.parse(document.getElementById('statusData').textContent);
    
    new Chart(statusCtx, {
        type: 'doughnut',
        data: {
            labels: statusData.labels,
            datasets: [{
                data: statusData.data,
                backgroundColor: [
                    '#43A047',  // Success color
                    '#FB8C00',  // Warning color
                    '#E53935',  // Danger color
                    '#757575'   // Medium color
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'bottom',
                }
            }
        }
    });
    
    // Inventory Value Trend Chart (if present)
    if (document.getElementById('trendChart')) {
        const trendCtx = document.getElementById('trendChart').getContext('2d');
        const trendData = JSON.parse(document.getElementById('trendData').textContent);
        
        new Chart(trendCtx, {
            type: 'line',
            data: {
                labels: trendData.labels,
                datasets: [{
                    label: 'Inventory Value',
                    data: trendData.data,
                    backgroundColor: 'rgba(46, 125, 50, 0.2)',
                    borderColor: '#2E7D32',
                    borderWidth: 2,
                    tension: 0.4,
                    pointBackgroundColor: '#2E7D32'
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return '$' + value;
                            }
                        }
                    }
                },
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return '$' + context.parsed.y;
                            }
                        }
                    }
                }
            }
        });
    }
}

// Delete confirmation for items
function confirmDelete(itemId, itemType) {
    if (confirm(`Are you sure you want to delete this ${itemType}? This action cannot be undone.`)) {
        document.getElementById(`delete-${itemType}-${itemId}`).submit();
    }
}

// Print report function
function printReport() {
    window.print();
}

// Export to CSV function
function exportToCSV(tableId, filename = 'export.csv') {
    const table = document.getElementById(tableId);
    if (!table) return;
    
    let csv = [];
    const rows = table.querySelectorAll('tr');
    
    for (let i = 0; i < rows.length; i++) {
        const row = [], cols = rows[i].querySelectorAll('td, th');
        
        for (let j = 0; j < cols.length; j++) {
            // Replace any commas in the cell content with spaces and wrap in quotes
            let cellText = cols[j].innerText.replace(/,/g, ' ');
            row.push('"' + cellText + '"');
        }
        
        csv.push(row.join(','));
    }
    
    // Create CSV file
    const csvFile = new Blob([csv.join('\n')], { type: 'text/csv' });
    
    // Download link
    const downloadLink = document.createElement('a');
    downloadLink.href = window.URL.createObjectURL(csvFile);
    downloadLink.download = filename;
    downloadLink.style.display = 'none';
    
    // Add to DOM and trigger download
    document.body.appendChild(downloadLink);
    downloadLink.click();
    document.body.removeChild(downloadLink);
}

// Dynamic form fields
function addFormField(containerId, template) {
    const container = document.getElementById(containerId);
    const fieldGroups = container.querySelectorAll('.field-group');
    const newIndex = fieldGroups.length;
    
    // Clone the template and update IDs and names
    const newField = document.createElement('div');
    newField.className = 'field-group';
    newField.innerHTML = template.replace(/\{index\}/g, newIndex);
    
    // Add remove button
    const removeButton = document.createElement('button');
    removeButton.type = 'button';
    removeButton.className = 'btn btn-small btn-danger';
    removeButton.innerHTML = '<i class="fas fa-times"></i>';
    removeButton.style.marginLeft = '10px';
    removeButton.onclick = function() {
        container.removeChild(newField);
    };
    
    newField.querySelector('.field-group-header').appendChild(removeButton);
    container.appendChild(newField);
}


