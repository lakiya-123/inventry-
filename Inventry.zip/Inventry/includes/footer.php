<?php if(isset($_SESSION['user_id'])): ?>
            </div><!-- /.content-body -->
        </main><!-- /.content -->
    </div><!-- /.app-container -->
    <?php endif; ?>

    <script src="assets/js/main.js"></script>
</body>
</html>