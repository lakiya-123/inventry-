<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Farm Inventory Management System</title>
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <?php if(isset($_SESSION['user_id'])): ?>
    <div class="app-container">
        <aside class="sidebar">
            <div class="sidebar-header">
                <h1>Green Garden Farm</h1>
                <span class="user-role"><?php echo $_SESSION['user_role']; ?></span>
            </div>
            
            <nav class="sidebar-nav">
                <ul>
                    <li><a href="index.php?page=dashboard" class="<?php echo $page == 'dashboard' ? 'active' : ''; ?>">
                        <i class="fas fa-tachometer-alt"></i> Dashboard
                    </a></li>
                    
                    <li><a href="index.php?page=inventory" class="<?php echo $page == 'inventory' ? 'active' : ''; ?>">
                        <i class="fas fa-boxes"></i> Inventory
                    </a></li>
                    
                    <li><a href="index.php?page=categories" class="<?php echo $page == 'categories' ? 'active' : ''; ?>">
                        <i class="fas fa-tags"></i> Categories
                    </a></li>
                    
                    <li><a href="index.php?page=reports" class="<?php echo $page == 'reports' ? 'active' : ''; ?>">
                        <i class="fas fa-chart-bar"></i> Reports
                    </a></li>
                    
                    <?php if(has_permission('admin')): ?>
                    <li><a href="index.php?page=users" class="<?php echo $page == 'users' ? 'active' : ''; ?>">
                        <i class="fas fa-users"></i> Users
                    </a></li>
                    <?php endif; ?>
                    
                    <li><a href="index.php?page=settings" class="<?php echo $page == 'settings' ? 'active' : ''; ?>">
                        <i class="fas fa-cog"></i> Settings
                    </a></li>
                </ul>
            </nav>
            
            <div class="sidebar-footer">
                <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </aside>
        
        <main class="content">
            <header class="content-header">
                <div class="menu-toggle">
                    <button id="sidebar-toggle"><i class="fas fa-bars"></i></button>
                </div>
                <div class="user-info">
                    <span class="user-name"><?php echo $_SESSION['user_name']; ?></span>
                    <div class="user-dropdown">
                        <button class="user-dropdown-btn">
                            <i class="fas fa-user-circle"></i>
                        </button>
                        <div class="user-dropdown-content">
                            <a href="index.php?page=settings&tab=profile"><i class="fas fa-user"></i> Profile</a>
                            <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
                        </div>
                    </div>
                </div>
            </header>
            
            <div class="content-body">
    <?php endif; ?>