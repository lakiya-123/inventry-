<?php
// Sanitize user input
function sanitize_input($data) {
    global $conn;
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    if (isset($conn)) {
        $data = $conn->real_escape_string($data);
    }
    return $data;
}

// Log activity
function log_activity($user_id, $action, $item_id, $item_type, $details) {
    global $conn;
    $stmt = $conn->prepare("INSERT INTO activity_log (user_id, action, item_id, item_type, details) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("isiss", $user_id, $action, $item_id, $item_type, $details);
    $stmt->execute();
}

// Get all categories
function get_categories($type = null) {
    global $conn;
    
    $sql = "SELECT * FROM categories";
    if ($type) {
        $sql .= " WHERE type = '$type'";
    }
    $sql .= " ORDER BY name ASC";
    
    $result = $conn->query($sql);
    $categories = [];
    
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $categories[] = $row;
        }
    }
    
    return $categories;
}

// Get category by ID
function get_category($id) {
    global $conn;
    
    $stmt = $conn->prepare("SELECT * FROM categories WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        return $result->fetch_assoc();
    }
    
    return null;
}

// Get inventory items with optional filters
function get_inventory($category_id = null, $search = null, $status = null, $limit = null, $offset = 0) {
    global $conn;
    
    $sql = "SELECT i.*, c.name as category_name, c.type as category_type 
            FROM inventory i 
            JOIN categories c ON i.category_id = c.id 
            WHERE 1=1";
    
    if ($category_id) {
        $sql .= " AND i.category_id = $category_id";
    }
    
    if ($search) {
        $sql .= " AND (i.name LIKE '%$search%' OR i.description LIKE '%$search%' OR i.location LIKE '%$search%')";
    }
    
    if ($status) {
        $sql .= " AND i.status = '$status'";
    }
    
    $sql .= " ORDER BY i.name ASC";
    
    if ($limit) {
        $sql .= " LIMIT $offset, $limit";
    }
    
    $result = $conn->query($sql);
    $inventory = [];
    
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $inventory[] = $row;
        }
    }
    
    return $inventory;
}

// Get inventory item by ID
function get_inventory_item($id) {
    global $conn;
    
    $stmt = $conn->prepare("SELECT i.*, c.name as category_name, c.type as category_type 
                           FROM inventory i 
                           JOIN categories c ON i.category_id = c.id 
                           WHERE i.id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        return $result->fetch_assoc();
    }
    
    return null;
}

// Count inventory items
function count_inventory($category_id = null, $search = null, $status = null) {
    global $conn;
    
    $sql = "SELECT COUNT(*) as count FROM inventory i WHERE 1=1";
    
    if ($category_id) {
        $sql .= " AND i.category_id = $category_id";
    }
    
    if ($search) {
        $sql .= " AND (i.name LIKE '%$search%' OR i.description LIKE '%$search%' OR i.location LIKE '%$search%')";
    }
    
    if ($status) {
        $sql .= " AND i.status = '$status'";
    }
    
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    
    return $row['count'];
}

// Update inventory status based on quantity and expiry date
function update_inventory_status() {
    global $conn;
    
    // Update expired items
    $sql = "UPDATE inventory SET status = 'expired' 
            WHERE expiry_date IS NOT NULL AND expiry_date < CURDATE() 
            AND status != 'expired'";
    $conn->query($sql);
    
    // Update out of stock items
    $sql = "UPDATE inventory SET status = 'out_of_stock' 
            WHERE quantity <= 0 AND status != 'expired'";
    $conn->query($sql);
    
    // Update low stock items
    $sql = "UPDATE inventory SET status = 'low_stock' 
            WHERE quantity > 0 AND quantity <= min_stock_level 
            AND status != 'expired' AND status != 'out_of_stock'";
    $conn->query($sql);
    
    // Update available items
    $sql = "UPDATE inventory SET status = 'available' 
            WHERE quantity > min_stock_level 
            AND (expiry_date IS NULL OR expiry_date >= CURDATE()) 
            AND status != 'available'";
    $conn->query($sql);
}

// Get counts for dashboard
function get_dashboard_counts() {
    global $conn;
    
    $counts = [
        'total_inventory' => 0,
        'low_stock' => 0,
        'out_of_stock' => 0,
        'expired' => 0,
        'categories' => 0,
        'livestock' => 0,
        'equipment' => 0,
        'crops' => 0,
        'supplies' => 0,
        'total_value' => 0
    ];
    
    // Update inventory status
    update_inventory_status();
    
    // Get total inventory count
    $result = $conn->query("SELECT COUNT(*) as count FROM inventory");
    $row = $result->fetch_assoc();
    $counts['total_inventory'] = $row['count'];
    
    // Get low stock count
    $result = $conn->query("SELECT COUNT(*) as count FROM inventory WHERE status = 'low_stock'");
    $row = $result->fetch_assoc();
    $counts['low_stock'] = $row['count'];
    
    // Get out of stock count
    $result = $conn->query("SELECT COUNT(*) as count FROM inventory WHERE status = 'out_of_stock'");
    $row = $result->fetch_assoc();
    $counts['out_of_stock'] = $row['count'];
    
    // Get expired count
    $result = $conn->query("SELECT COUNT(*) as count FROM inventory WHERE status = 'expired'");
    $row = $result->fetch_assoc();
    $counts['expired'] = $row['count'];
    
    // Get categories count
    $result = $conn->query("SELECT COUNT(*) as count FROM categories");
    $row = $result->fetch_assoc();
    $counts['categories'] = $row['count'];
    
    // Get count by category type
    $types = ['livestock', 'equipment', 'crops', 'supplies'];
    foreach ($types as $type) {
        $result = $conn->query("SELECT COUNT(*) as count FROM inventory i 
                               JOIN categories c ON i.category_id = c.id 
                               WHERE c.type = '$type'");
        $row = $result->fetch_assoc();
        $counts[$type] = $row['count'];
    }
    
    // Get total inventory value
    $result = $conn->query("SELECT SUM(quantity * price) as total FROM inventory");
    $row = $result->fetch_assoc();
    $counts['total_value'] = $row['total'] ? $row['total'] : 0;
    
    return $counts;
}

// Format currency
function format_currency($amount) {
    return 'Rs. ' . number_format($amount, 2, '.', ',');
}

// Get recent activities
function get_recent_activities($limit = 10) {
    global $conn;
    
    $sql = "SELECT a.*, u.username, u.full_name 
            FROM activity_log a 
            JOIN users u ON a.user_id = u.id 
            ORDER BY a.created_at DESC 
            LIMIT $limit";
    
    $result = $conn->query($sql);
    $activities = [];
    
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $activities[] = $row;
        }
    }
    
    return $activities;
}

// Check if user has permission
function has_permission($required_role) {
    if (!isset($_SESSION['user_role'])) {
        return false;
    }
    
    // Define role hierarchy
    $roles = [
        'admin' => 3,
        'manager' => 2,
        'staff' => 1
    ];
    
    $user_role_level = $roles[$_SESSION['user_role']];
    $required_role_level = $roles[$required_role];
    
    return $user_role_level >= $required_role_level;
}
?>