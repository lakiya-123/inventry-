<?php
// Database connection parameters
$host = "localhost";
$username = "root";
$password = "";
$database = "farm_inventory";

// Create connection
$conn = new mysqli($host, $username, $password);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if database exists, if not create it
$sql = "CREATE DATABASE IF NOT EXISTS $database";
if ($conn->query($sql) !== TRUE) {
    die("Error creating database: " . $conn->error);
}

// Select the database
$conn->select_db($database);

// Create tables if they don't exist
$tables = [
    "CREATE TABLE IF NOT EXISTS users (
        id INT(11) AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        full_name VARCHAR(100) NOT NULL,
        email VARCHAR(100) NOT NULL,
        role ENUM('admin', 'manager', 'staff') NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )",
    
    "CREATE TABLE IF NOT EXISTS categories (
        id INT(11) AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(50) NOT NULL,
        description TEXT,
        type ENUM('livestock', 'equipment', 'crops', 'supplies') NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )",
    
    "CREATE TABLE IF NOT EXISTS inventory (
        id INT(11) AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        category_id INT(11) NOT NULL,
        quantity INT(11) NOT NULL DEFAULT 0,
        unit VARCHAR(20) NOT NULL,
        price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
        purchase_date DATE,
        expiry_date DATE NULL,
        min_stock_level INT(11) DEFAULT 0,
        location VARCHAR(100),
        status ENUM('available', 'low_stock', 'out_of_stock', 'expired') DEFAULT 'available',
        description TEXT,
        image VARCHAR(255),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE
    )",
    
    "CREATE TABLE IF NOT EXISTS activity_log (
        id INT(11) AUTO_INCREMENT PRIMARY KEY,
        user_id INT(11) NOT NULL,
        action VARCHAR(50) NOT NULL,
        item_id INT(11),
        item_type VARCHAR(50) NOT NULL,
        details TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    )"
];

// Execute table creation
foreach ($tables as $sql) {
    if ($conn->query($sql) !== TRUE) {
        echo "Error creating table: " . $conn->error;
    }
}

// Create default admin user if no users exist
$result = $conn->query("SELECT COUNT(*) as count FROM users");
$row = $result->fetch_assoc();

if ($row['count'] == 0) {
    $default_password = password_hash("admin123", PASSWORD_DEFAULT);
    $sql = "INSERT INTO users (username, password, full_name, email, role) 
            VALUES ('admin', '$default_password', 'System Administrator', 'admin@farm.com', 'admin')";
    $conn->query($sql);
}

// Create default categories if none exist
$result = $conn->query("SELECT COUNT(*) as count FROM categories");
$row = $result->fetch_assoc();

if ($row['count'] == 0) {
    $default_categories = [
        ["Cattle", "All types of cattle and cows", "livestock"],
        ["Poultry", "Chickens, ducks and other birds", "livestock"],
        ["Tractors", "Farm tractors and attachments", "equipment"],
        ["Hand Tools", "Manual farm tools", "equipment"],
        ["Seeds", "All types of seeds for planting", "crops"],
        ["Fertilizers", "Chemical and organic fertilizers", "supplies"],
        ["Animal Feed", "Food for livestock", "supplies"]
    ];
    
    $stmt = $conn->prepare("INSERT INTO categories (name, description, type) VALUES (?, ?, ?)");
    foreach ($default_categories as $category) {
        $stmt->bind_param("sss", $category[0], $category[1], $category[2]);
        $stmt->execute();
    }
}
?>