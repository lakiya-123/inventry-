-- Farm Inventory Management System Database Schema

-- Users Table
CREATE TABLE IF NOT EXISTS users (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    role ENUM('admin', 'manager', 'staff') NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Categories Table
CREATE TABLE IF NOT EXISTS categories (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    description TEXT,
    type ENUM('livestock', 'equipment', 'crops', 'supplies') NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Inventory Table
CREATE TABLE IF NOT EXISTS inventory (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    category_id INT(11) NOT NULL,
    quantity INT(11) NOT NULL DEFAULT 0,
    unit VARCHAR(20) NOT NULL,
    price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    purchase_date DATE,
    expiry_date DATE NULL,
    min_stock_level INT(11) DEFAULT 0,
    location VARCHAR(100),
    status ENUM('available', 'low_stock', 'out_of_stock', 'expired') DEFAULT 'available',
    description TEXT,
    image VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE
);

-- Activity Log Table
CREATE TABLE IF NOT EXISTS activity_log (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    user_id INT(11) NOT NULL,
    action VARCHAR(50) NOT NULL,
    item_id INT(11),
    item_type VARCHAR(50) NOT NULL,
    details TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Insert default admin user
INSERT INTO users (username, password, full_name, email, role) 
VALUES ('admin', '$2y$10$8K1p/hzwJLIEkAQBQ5hp7.fD0UYygCnQozV0cRKlWxmMlVj3nKZ0W', 'System Administrator', 'admin@farm.com', 'admin');

-- Insert default categories
INSERT INTO categories (name, description, type) VALUES
('Cattle', 'All types of cattle and cows', 'livestock'),
('Poultry', 'Chickens, ducks and other birds', 'livestock'),
('Tractors', 'Farm tractors and attachments', 'equipment'),
('Hand Tools', 'Manual farm tools', 'equipment'),
('Seeds', 'All types of seeds for planting', 'crops'),
('Fertilizers', 'Chemical and organic fertilizers', 'supplies'),
('Animal Feed', 'Food for livestock', 'supplies');

CREATE TABLE retrieval_log (
  id INT AUTO_INCREMENT PRIMARY KEY,
  item_id INT,
  quantity INT,
  retrieved_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table for Appearance Settings
CREATE TABLE appearance_settings (
    user_id INT PRIMARY KEY,
    theme VARCHAR(20) DEFAULT 'light',
    font_size VARCHAR(20) DEFAULT 'medium',
    sidebar_position VARCHAR(20) DEFAULT 'left',
    items_per_page INT DEFAULT 10,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Table for Notification Settings
CREATE TABLE notification_settings (
    user_id INT PRIMARY KEY,
    email_low_stock BOOLEAN DEFAULT FALSE,
    email_expiry BOOLEAN DEFAULT FALSE,
    email_activity BOOLEAN DEFAULT FALSE,
    notify_low_stock BOOLEAN DEFAULT TRUE,
    notify_expiry BOOLEAN DEFAULT TRUE,
    notify_activity BOOLEAN DEFAULT TRUE,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Table for System Settings (Admin Only)
CREATE TABLE system_settings (
    id INT PRIMARY KEY AUTO_INCREMENT,
    system_name VARCHAR(255) DEFAULT 'Farm Inventory Management System',
    company_name VARCHAR(255) DEFAULT 'Your Farm Name',
    currency VARCHAR(10) DEFAULT 'USD',
    date_format VARCHAR(20) DEFAULT 'm/d/Y',
    last_updated_by INT,
    last_updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (last_updated_by) REFERENCES users(id)
);